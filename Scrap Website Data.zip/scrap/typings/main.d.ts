/// <reference path="main\ambient\jquery\jquery.d.ts" />
