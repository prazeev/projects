/// <reference path="browser\ambient\jquery\jquery.d.ts" />
