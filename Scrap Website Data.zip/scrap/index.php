<?php
header('Location: scrap');