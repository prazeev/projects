<?php
header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-datepicker.min.css">
<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Shadows Into Light:r">
<style type="text/css">
    .wizard {
        margin: 20px auto;
        background: #fff;
    }

    body {
        color: #3b3b3b;
        font-family: "Gill Sans","Gill Sans MT",Calibri,sans-serif;
        font-size: 16px;
        font-style: normal;
        font-weight: 300;
    }

    .container {
        width:96%;
    }
    .container-left {
        background-color: #eee;
        float: left;
        margin-left: 5px;
        padding: 5px;
        width: 67%;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    ul.pull-right .btn-primary {
        float:right;
    }
    .btn-danger {
        float: left;
    }
    .btn { 
        margin: 0 20px;
    }

    .quote-footer, .dec-footer, .dat-footer {
        font-size:12px;
    }
    .quote-footer {
        padding:10px 20px;
    }
    .dat-footer div  {
        padding:10px; 
        border: 1px solid #ccc;
        border-radius: 5px;
        background-color: #eee;
    }
    blockquote {
        font-style: italic;
        font-size:17px;
    }
    .testi-name {
        color:#16afec;
    }
    .col-xs-9 select.form-control {
        float: left;
        width: 122%;
    }
    .dob-section .col-md-4 {
        display: inline-table;
    }
    .container-right {
        width: 30%;
        float:right;
        padding:0 10px;  
    }
    .container-right h3 {
        margin-top: 50px !important;
    }
    .container-right .row1-right h3 {
        margin-top: 0px !important;
    }

    .wizard .nav-tabs {
        position: relative;
        margin: 40px auto;
        margin-bottom: 0;
        border-bottom-color: #e0e0e0;
    }

    .wizard > div.wizard-inner {
        position: relative;
    }
    .btn-primary {
        background: #93B74A;
        border-color:  #93B74A;
        width: 264px;
    }

    .connecting-line {
        height: 2px;
        background: #e0e0e0;
        position: absolute;
        width: 80%;
        margin: 0 auto;
        left: 0;
        right: 0;
        top: 50%;
        z-index: 1;
    }

    .wizard .nav-tabs > li.active > a, .wizard .nav-tabs > li.active > a:hover, .wizard .nav-tabs > li.active > a:focus {
        color: #555555;
        cursor: default;
        border: 0;
        border-bottom-color: transparent;
    }
    .indent {
        text-indent: -1.7em;
    }
    span.round-tab {
        width: 70px;
        height: 70px;
        line-height: 70px;
        display: inline-block;
        border-radius: 100px;
        background: #fff;
        border: 2px solid #e0e0e0;
        z-index: 2;
        position: absolute;
        left: 0;
        text-align: center;
        font-size: 25px;
        padding-top: 30%;
    }
    span.round-tab i{
        color:#555555;
    }
    .wizard li.active span.round-tab {
        background: #fff;
        border: 2px solid #5bc0de;

    }
    .wizard li.active span.round-tab i{
        color: #5bc0de;
    }

    span.round-tab:hover {
        color: #333;
        border: 2px solid #333;
    }

    .wizard .nav-tabs > li {
        width: 25%;
    }

    .wizard li:after {
        content: " ";
        position: absolute;
        left: 46%;
        opacity: 0;
        margin: 0 auto;
        bottom: 0px;
        border: 5px solid transparent;
        border-bottom-color: #5bc0de;
        transition: 0.1s ease-in-out;
    }

    .wizard li.active:after {
        content: " ";
        position: absolute;
        left: 46%;
        opacity: 1;
        margin: 0 auto;
        bottom: 0px;
        border: 10px solid transparent;
        border-bottom-color: #5bc0de;
    }

    .wizard .nav-tabs > li a {
        width: 70px;
        height: 70px;
        margin: 20px auto;
        border-radius: 100%;
        padding: 0;
    }

    .wizard .nav-tabs > li a:hover {
        background: transparent;
    }

    .wizard .tab-pane {
        position: relative;
        padding-top: 50px;
    }
    .red {
        color:red;
    }
    .wizard h3 {
        margin-top: 0;
        color: #5e5e5e;
        font-family: "Shadows Into Light",sans-serif;
        font-size: 26px;
        font-weight: bold;
    }
    .step1 .row {
        margin-bottom:10px;
    }
    .step_21 {
        border :1px solid #eee;
        border-radius:5px;
        padding:10px;
    }
    .step33 {
        border:1px solid #ccc;
        border-radius:5px;
        padding-left:10px;
        margin-bottom:10px;
    }
    .dropselectsec {
        width: 68%;
        padding: 6px 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        color: #333;
        margin-left: 10px;
        outline: none;
        font-weight: normal;
    }
    .dropselectsec1 {
        width: 74%;
        padding: 6px 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        color: #333;
        margin-left: 10px;
        outline: none;
        font-weight: normal;
    }
    .mar_ned {
        margin-bottom:10px;
    }
    .wdth {
        width:25%;
    }
    .birthdrop {
        padding: 6px 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        color: #333;
        margin-left: 10px;
        width: 16%;
        outline: 0;
        font-weight: normal;
    }


    /* according menu */
    #accordion-container {
        font-size:13px
    }
    .accordion-header {
        font-size:13px;
        background:#ebebeb;
        margin:5px 0 0;
        padding:7px 20px;
        cursor:pointer;
        color:#fff;
        font-weight:400;
        -moz-border-radius:5px;
        -webkit-border-radius:5px;
        border-radius:5px
    }
    .unselect_img{
        width:18px;
        -webkit-user-select: none;  
        -moz-user-select: none;     
        -ms-user-select: none;      
        user-select: none; 
    }
    .active-header {
        -moz-border-radius:5px 5px 0 0;
        -webkit-border-radius:5px 5px 0 0;
        border-radius:5px 5px 0 0;
        background:#F53B27;
    }
    .active-header:after {
        content:"\f068";
        font-family:'FontAwesome';
        float:right;
        margin:5px;
        font-weight:400
    }
    .inactive-header {
        background:#333;
    }
    .inactive-header:after {
        content:"\f067";
        font-family:'FontAwesome';
        float:right;
        margin:4px 5px;
        font-weight:400
    }
    input[type="checkbox"] {
        border: 1px solid black;
        height: 20px;
        vertical-align: middle;
        width: 20px;
        margin: 0;
    }
    .accordion-content {
        display:none;
        padding:20px;
        background:#fff;
        border:1px solid #ccc;
        border-top:0;
        -moz-border-radius:0 0 5px 5px;
        -webkit-border-radius:0 0 5px 5px;
        border-radius:0 0 5px 5px
    }
    .accordion-content a{
        text-decoration:none;
        color:#333;
    }
    .accordion-content td{
        border-bottom:1px solid #dcdcdc;
    }

    .passport {
        font-size: 18px;
        font-weight: bold;
        width: 170px;
        padding: 20px;
        background: #fff;
        border: 3px solid #a3c15c;
        text-align: center;
    }
    .radio-checkbox {
        width: 24px;
        height: 24px;
        background-color: #fff;
        border: solid 3px #a3c15c;
        float: left;
        margin-left: 174px;
        font-size: 18px;
    }
    .rectangle1 {
        border-radius: 5px;
        background: #ffffff;
        border: 1px solid black;
        padding: 20px; 
        width: 100%;
        height: auto;
    }

    .table-bg{
        margin: -13px 0 -13px 0;
        padding-top: 2px;
    }
    .euro{
        font-size: 35px;
        color: #CF232B;
        font-weight: bold;



    }
    .euro::before{
        content:"\00a3";
        text-indent: -10px;
    }
    .h3{
        margin-top: -6px;
        color: #5e5e5e;
        font-family: "Shadows Into Light",sans-serif;
        font-size: 34px;
        font-weight: bold;
    }
    .h4{
        margin-top:-10px;
        text-decoration: none;
        transform:scale(1,1.3); 
        margin-bottom: 4px;
    }
    .h5{
        margin-top: -0.5em;
        text-decoration: none;
        margin-bottom: 4px;
        font-weight:normal;
    }
    .li {
        outline-style: none;
    }
    .table-head{
        padding-top: 1.2em;
        text-align: left;
        padding-left: 8px;
    }
    .ul{
        margin-top: 0.1em;
        text-decoration: none;
    }
    .button{
        border-radius: 5px;
        background: #000;
        color:#fff;
        border: 1px solid #97C83C;
        padding: 15px;
        width: 90%;
        min-height: auto;
        word-wrap:break-word;
        color:white;
    }

    #b1,#b2 {
        width: 335px;
    }
    .delete {
        cursor: pointer;
    }
    .say-yes:hover, .say-yes:active, .say-yes:focus,
    .say-no:hover, .say-no:active, .say-no:focus {
        color: #fe0000;
    }
    @media( max-width : 585px ) {

        .wizard {
            width: 90%;
            height: auto !important;
        }

        span.round-tab {
            font-size: 16px;
            width: 50px;
            height: 50px;
            line-height: 50px;
        }

        .wizard .nav-tabs > li a {
            width: 50px;
            height: 50px;
            line-height: 50px;
        }

        .wizard li.active:after {
            content: " ";
            position: absolute;
            left: 35%;
        }
    }
</style>

<div class="container">
    <div class="row">
        <section>
            <div class="wizard">
                <div class="wizard-inner">
                    <div class="connecting-line"></div>
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation" class="active">
                            <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="Your Details">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-folder-open"></i>
                                </span>
                            </a>
                        </li>

                        <li role="presentation" class="disabled">
                            <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="Your Quote & Summary">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-pencil"></i>
                                </span>
                            </a>
                        </li>
                        <li role="presentation" class="disabled">
                            <a href="#step3" data-toggle="tab" aria-controls="step3" role="tab" title="Your Choices of Cover">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-picture"></i>
                                </span>
                            </a>
                        </li>

                        <li role="presentation" class="disabled">
                            <a href="#complete" data-toggle="tab" aria-controls="complete" role="tab" title="Complete">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-ok"></i>
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>

                <form role="form" id="myForm" action="formsubmit.php" method="post">
                    <div class="tab-content">
                        <div class="tab-pane active" role="tabpanel" id="step1">
                            <div class="container-right">
                                <div class="row1-right">
                                    <h3>EduHealth - We are at your service...</h3>
                                    <p>If you work in the education sector and are looking for Private Medical Insurance, Income Protection, Life Insurance or any of a specialist range of other valuable lifestyle protection services then EduHealth can help you.
                                        EduHealth are recognised industry experts in the healthcare market with long experience in providing welcome solutions, cover and protection when it is needed most.</p>
                                </div>
                                <div class="row2-right">
                                    <blockquote style="margin-top:30px;">"We have found the Eduhealth service to be very good, and our staff have greatly appreciated the benefits of the plans you have put in place for us. Calls are always answered and dealt with when we need help."<br><br>
                                        <span class="testi-name">Jennifer Leigh</span>, Business Manager
                                        Rodborough College</blockquote>
                                </div>
                            </div>
                            <div class="step1 container-left">
                                <h3>Your Details</h3>
                                <div class="row">
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <b>Title: </b>
                                    </div>
                                    <div class="col-xs-2 col-sm-2 col-md-2">
                                        <div class="form-group">
                                            <select name="data-title" class="form-control input-sm" placeholder="Title" required="required">
                                                <option value="Mr.">Mr.</option>
                                                <option value="Mrs.">Mrs.</option>
                                                <option value="Ms.">Ms.</option>
                                                <option value="Miss">Miss</option>
                                                <option value="Dr.">Dr.</option>
                                                <option value="Prof">Prof</option>
                                                <option value="Sir">Sir</option>
                                                <option value="Dame">Dame</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xs-2 col-sm-2 col-md-2" style="text-align: right;">
                                        <b>Firstname:</b>
                                    </div>
                                    <div class="col-xs-5 col-sm-5 col-md-5">
                                        <div class="form-group">
                                            <input type="text" name="data-fname" id="fname" class="form-control input-sm" placeholder="Firstname" required="required">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <b>Surname: </b>
                                    </div>
                                    <div class="col-xs-9 col-sm-9 col-md-9">
                                        <div class="form-group">
                                            <input type="text" name="data-lname" id="lname" class="form-control input-sm" placeholder="Surname" required="required">
                                        </div>
                                    </div>
                                </div>

                                <div class="row dob-section">
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <b>Date of Birth: </b>
                                    </div>
                                    <div class="col-xs-9 col-sm-9 col-md-9">
                                        <select class="form-control" style="width: auto;margin-right: 10px;" name="data-dob-dd" required="required">
                                            <?php
                                            for ($i = 1; $i < 32; $i++)
                                                echo '<option value="' . $i . '">' . $i . '</option>';
                                            ?>
                                        </select>
                                        <select class="form-control" style="width: auto;margin-right: 10px;" name="data-dob-mm" required="required">
                                            <option value="1">January</option>
                                            <option value="2">February</option>
                                            <option value="3">March</option>
                                            <option value="4">April</option>
                                            <option value="5">May</option>
                                            <option value="6">June</option>
                                            <option value="7">July</option>
                                            <option value="8">August</option>
                                            <option value="9">September</option>
                                            <option value="10">October</option>
                                            <option value="11">November</option>
                                            <option value="12">December</option>
                                        </select>
                                        <select class="form-control" style="width: auto;" name="data-dob" required="required">
                                            <?php
                                            for ($i = Date('Y'); $i > 1899; $i--) {
                                                echo '<option value="' . $i . '">' . $i . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                </div>

                                <div class="row">
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <b>Gender: </b>
                                    </div>
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <div class="form-group">
                                            <select name="data-gender" class="form-control input-sm" placeholder="Gender" required="required">
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xs-2 col-sm-2 col-md-2">
                                        <b>Occupation: </b>
                                    </div>
                                    <div class="col-xs-4 col-sm-4 col-md-4">
                                        <div class="form-group">
                                            <input name="data-occupation" class="form-control input-sm" placeholder="Occupation" required="required">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                </div>

                                <div class="row">
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <b>Telephone: </b>
                                    </div>
                                    <div class="col-xs-9 col-sm-9 col-md-9">
                                        <div class="form-group">
                                            <input type="tel" name="data-telephone" id="telephone" class="form-control input-sm" placeholder="Telephone" required="required">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <b>Email: </b>
                                    </div>
                                    <div class="col-xs-9 col-sm-9 col-md-9">
                                        <div class="form-group">
                                            <input type="email" name="data-email" id="email" class="form-control input-sm" placeholder="Email" required="required">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <b>Postcode: </b>
                                    </div>
                                    <div class="col-xs-9 col-sm-9 col-md-9">
                                        <div class="form-group">
                                            <input type="text" name="data-postcode" id="postcode" class="form-control input-sm" placeholder="Postcode" required="required">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <b>Address: </b>
                                    </div>
                                    <div class="col-xs-9 col-sm-9 col-md-9">
                                        <div class="form-group">
                                            <textarea name="data-address" id="address" class="form-control input-sm" placeholder="Address" required="required"></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xs-3 col-sm-3 col-md-3">
                                        <b>Start date: </b>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="date form-control" name="data-sdate" required="required">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <h3>Your Family</h3>
                                        <table class="table table-hover table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Title</th>
                                                    <th>First</th>
                                                    <th>Surname</th>
                                                    <th>Birthdate</th>
                                                    <th>Relationship</th>
                                                    <th>Gender</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody class="family">
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="btn btn-default btn-sm" id="add">Add Family Member</div>
                                </div>
                                <div class="row quote-footer"><p>By applying for this quote or insurance you are responsible for providing complete and accurate information. In deciding to accept this policy and in setting the terms and premium, the insurer relies on the information you provide in this form. Inaccurate or false information could adversely affect any claim.</p>
                                    <p>Data Protection: By completing and submitting this quote and proposal you are agreeing to allow EduHealth to contact you in relation to this application and other products and services provided by EduHealth. EduHealth do share or pass your information to any third parties other than those involved in the acceptance and administration of this insurance.</p>
                                </div>
                                <div class="row">
                                    <button class="btn btn-default btn-lg" onclick="reset()">Reset</button></li>
                                    <button type="button" class="btn btn-primary btn-lg pull-right next-step stepone">Click Here For Your Quote</button>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" role="tabpanel" id="step2">
                            <div class="container-right">
                                <div class="row1-right">
                                    <h3>Your choice of acceptance terms</h3>
                                    <p>If you accept the quote and choose to join online you will be accepting our Moratorium terms.</p>
                                    <p>With moratorium underwriting terms there is no need to provide the insurer with complete health information but instead, you accept that any medical conditions for which you have suffered symptoms, sought or received medical advice or treatment or taken medication, prescribed or not, in the last 5 years will be not be covered by the plan.</p>
                                    <p>But such conditions may be covered after 2 years from the start date if you remain free of symptoms, medical advice, treatment or medication prescribed or not.</p>
                                    <p>You may instead choose to be fully medically underwritten whereby you complete a medical questionnaire. Alternatively, if you already have a plan with another insurer and wish to transfer we can provide cover under our Continued Personal Medical Exclusions (CPME) terms.</p>
                                    <p>If you wish to take advantage of either of these options please call our Customer Service Team on 0345 226 9938</p>
                                </div>
                                <div class="row2-right">
                                    <h3>Important Information:</h3>
                                    <p>Essentials brochure</p>
                                    <p>Essentials Key Facts - Product Summary</p>
                                    <p>Essentials Members Guide & Policy Document</p>
                                    <p>EduHealth Key Facts</p>
                                </div>
                                <div class="row3-right">
                                    <h3>Contact Us:</h3>
                                    <p><b>T: 0345 266 9938</b></p>
                                    <p><b>E:</b> Info@EduHealth.co.uk</p>
                                    <p><b>A:</b> Sadler's House, 4-6 South Parade, Bawtry, South Yorkshire DN10 6JH</p>
                                </div>
                            </div>
                            <div class="step2 container-left">
                                <div class="step_21">
                                    <div class="row">
                                        <div class="col-md-12"><h3>Your Quotes and Summary</h3></div>
                                        <div style="padding-left: 50px"><b>Choose your excess level (tick a box):</b></div>
                                        <br>
                                        <div class="row" style="padding-left: 100px">
                                            <div class="col-md-6 col-sm-6">
                                                <label style="font-weight: normal;cursor: pointer;"><input class="hidden" type="radio" name="excess-type" value="NIL">
                                                    <div class="radio-checkbox"><i class="glyphicon glyphicon-ok" style="display: none"></i></div>
                                                    <div class="passport"><center>Premium: <br><span style="font-size: 18px;color:#ce222b;">&pound;<span class="passport-data-month-first"></span> </span><br>per month<br>NIL EXCESS</center></div>
                                                </label>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <label style="font-weight: normal;cursor: pointer;"><input class="hidden" type="radio" name="excess-type" value="£100">
                                                    <div class="radio-checkbox"><i class="glyphicon glyphicon-ok" style="display: none"></i></div>
                                                    <div class="passport"><center>Premium: <br><span style="font-size: 18px;color:#ce222b;">&pound;<span class="passportplus-data-month-first"></span> </span><br>per month<br>£100 EXCESS</center></div>
                                                </label>
                                            </div>
                                        </div>
                                        <input type="hidden" name="data-excesstype">
                                        <br>
                                        <center><i>Your quote includes insurance premium tax and is based on your responses given below:</i></center>
                                        <hr>
                                        <div class="col-md-12"><h3>Covering</h3></div>
                                        <div class="col-md-12">
                                            <table class="table table-hover table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>Title</th>
                                                        <th>First</th>
                                                        <th>Surname</th>
                                                        <th>Birth date</th>
                                                        <th>Gender</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td><span class="title"></span></td>
                                                        <td><span class="fname"></span></td>
                                                        <td><span class="lname"></span></td>
                                                        <td><span class="dob"></span></td>
                                                        <td><span class="gender"></span></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-md-12"><h3>And:</h3></div>
                                        <div class="col-md-12">
                                            <table class="table table-hover table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>Title</th>
                                                        <th>First</th>
                                                        <th>Surname</th>
                                                        <th>Birth date</th>
                                                        <th>Relation</th>
                                                        <th>Gender</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="family-members">

                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div><b>Address</b></div>
                                                    <div style="background-color: #fff;padding: 5px;">
                                                        <div class="address"></div>
                                                    </div>
                                                    <br>
                                                    <div><b>Telephone</b></div>
                                                    <div style="background-color: #fff;padding: 5px;">
                                                        <div class="telephone"></div>
                                                    </div>
                                                    <br>
                                                    <div><b>Occupation</b></div>
                                                    <div style="background-color: #fff;padding: 5px;">
                                                        <div class="occupation"></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div><b>Postcode</b></div>
                                                    <div style="background-color: #fff;padding: 5px;">
                                                        <div class="postcode"></div>
                                                    </div>
                                                    <br>
                                                    <div><b>Email</b></div>
                                                    <div style="background-color: #fff;padding: 5px;">
                                                        <div class="email"></div>
                                                    </div>
                                                    <br>
                                                    <div><b>Start Date</b></div>
                                                    <div style="background-color: #fff;padding: 5px;">
                                                        <div class="sdate"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="row" style="margin-top: 20px;">
                                                <div class="col-md-12">
                                                    <button type="button" class="btn btn-default prev-step stepone btn-lg" style="margin: 0">Change My Details</button>
                                                    <span id="button-to-2nd-last-outer" class="pull-right"><button type="button" id="button-to-2nd-last" class="btn btn-primary btn-info-full next-step btn-lg stepone" style="margin: 0" disabled>Click Here To Be Covered</button></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--
                            <div class="jumbotron">
                                <div class="row">
                                <div class="col-md-12">
                                    <center>
                                        <div class="rectangle1">
                                            <table width="100%" border="0" class="table-bg">
                                                <tbody> 
                                                    <tr>
                                                        <td align="center" style="width:33%;border-right:2px solid #888888">
                                                            <h2 class="h2">Essentials</h2>
                                                            <h4 class="h4">only</h4>
                                                            <span class="euro"><span class="passport-data-month"></span></span>
                                                            <h2 class="h2">per month</h2>
                                                            <h5 class="h5">(includes insurance premium tax)</h5> 
                                                        </td>
                                                        <td align="center" style="width:33%;">
                                                            
                                                                <div class="table-head">Fully Comprehensive Cover:</div> 
                                                                <ul style="text-align:left;" class="ul">
                                                                    <li>Outpatient benefits</li>
                                                                    <li>Day and Inpatient benefits </li>
                                                                    <li>Advanced Cancer Cover </li>
                                                                    <li>Wide choice of hospitals</li>
                                                                    <li>Many other extra benefits</li>
                                                                </ul>
                                                            
                                                        </td>
                                                        <td align="left" style="width:33%">
                                                            <button type="button" class="btn btn-primary btn-lg next-step" id="b1">Click Here to choose Essentials >>></button>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </center>
                                </div>
                                </div>
                                <hr>
                                <div class="row">
                                <div class="col-md-12">
                                    <center>
                                        <div class="rectangle1">
                                            <table width="100%" border="0" class="table-bg">
                                                <tbody> 
                                                    <tr>
                                                        <td align="center" style="width:33%;border-right:2px solid #888888">
                                                            <h2 class="h2">Essentials PLUS</h2>
                                                            <h4 class="h4">only</h4>
                                                            <span class="euro"><span class="passportplus-data-month"></span></span>
                                                            <h2 class="h2">per month</h2>
                                                            <h5 class="h5">(includes insurance premium tax)</h5> 
                                                        </td>
                                                        <td align="center" style="width:33%;">
                                                           
                                                                <div class="table-head">Additional valuable benefits for specific serious conditions: </div> 
                                                                <ul style="text-align:left;" class="ul">
                                                                    <li>Access to world's best doctors and medical facilities</li>
                                                                    <li>Travel and accommodation expenses including companion</li>
                                                                    <li> Cash and repatriation benefits </li>
                                                                </ul>
                                                          
                                                        </td>
                                                        <td align="left" style="width:34%;text-align: left;">
                                                            <button type="button" class="btn btn-primary btn-lg next-step" id="b2">Click Here to choose Essentials PLUS >>></button>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </center>
                                </div>
                                </div>
                            </div>
                            -->
                        </div>
                        <div class="tab-pane" role="tabpanel" id="step3">
                            <div class="container-right">
                                <div class="row1-right">
                                    <h3>Important Information:</h3>
                                    <p>Essentials brochure</p>
                                    <p>Essentials Key Facts - Product Summary</p>
                                    <p>Essentials Members Guide & Policy Document</p>
                                    <p>EduHealth Key Facts</p>
                                </div>
                                <div class="row2-right">
                                    <h3>Contact Us:</h3>
                                    <p><b>T: 0345 266 9938</b></p>
                                    <p><b>E:</b> Info@EduHealth.co.uk</p>
                                    <p><b>A:</b> Sadler's House, 4-6 South Parade, Bawtry, South Yorkshire DN10 6JH</p>
                                </div>
                                <div class="row3-right">
                                    <div id="dat-protection" class="dat-footer">
                                        <h3>Data Protection Act 1998</h3>
                                        <div>
                                            <p>I confirm and agree that this application form and any associated forms may be stored on paper or electronically by EduHealth. It may also be used by AmTrust Europe Limited (the insurer) and others that provide services for the administration of this policy. EduHealth and the insurer also use the information that I have provided to deal with claims that I may make under the policy. I understand that they may also need to obtain and use sensitive and personal information in carrying out these tasks. The insurer may use and share your information with other members of the AmTrust group companies (The Group). The Group contains companies based throughout the world, both inside and outside Europe (for example, in the USA). By purchasing this policy you have consented to your data being stored and processed in the USA.  We will provide an adequate level of protection to your data.</p>
                                            <p>I further understand that this information and other information gathered in any claim I make may be shared with other insurers and third parties in the prevention of fraud. Details of other insurers and third parties will be made available to me on request. Where I have answered any questions requiring the disclosure of sensitive personal data or provided additional information, including any medical information from any doctor both now and in the future, by signing this form, I also consent to the insurer using this information for the above purposes. I agree to notify EduHealth immediately, should any answers to this declaration change between now and policy inception.</p>
                                            <p>We may also send you information about other products and services that may be of interest.</p>
                                            <p>If you do not wish to receive such information then please tick this box: <input type="checkbox" name="data-mailing" value="Yes"/></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="passportplus-ch step33 container-left">
                                <div class="row" id="3a">
                                    <!--
                                    <div class="col-md-12">
                                        <div style="min-height:400px;"></div>
                                    </div>
                                    -->


                                    <div class="col-md-12">
                                        <div>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-12"><h3>Your Quote and Summary</h3></div>
                                                <div class="col-md-12">
                                                    <div class="row" style="margin-bottom: 20px;">
                                                        <div class="col-md-6">
                                                            <div><b>Monthly Premium:</b></div>
                                                            <div style="background-color: #fff;padding: 5px;">
                                                                £<span class="excess-data-month-first"></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div><b>Excess:</b></div>
                                                            <div style="background-color: #fff;padding: 5px;">
                                                                <span class="excesstype"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12"><h3>Covering</h3></div>
                                                <div class="col-md-12">
                                                    <table class="table table-hover table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th>Title</th>
                                                                <th>First</th>
                                                                <th>Surname</th>
                                                                <th>Birth date</th>
                                                                <th>Gender</th>
                                                                <th>Occupation</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td><span class="title"></span></td>
                                                                <td><span class="fname"></span></td>
                                                                <td><span class="lname"></span></td>
                                                                <td><span class="dob"></span></td>
                                                                <td><span class="gender"></span></td>
                                                                <td><span class="occupation"></span></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="col-md-12"><h3>And:</h3></div>
                                                <div class="col-md-12">
                                                    <table class="table table-hover table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th>Title</th>
                                                                <th>First</th>
                                                                <th>Surname</th>
                                                                <th>Birth date</th>
                                                                <th>Relation</th>
                                                                <th>Gender</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="family-members">

                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="col-md-12"><div class="row">
                                                        <div class="col-md-6">
                                                            <div><b>Address</b></div>
                                                            <div style="background-color: #fff;padding: 5px;">
                                                                <div class="address"></div>
                                                            </div>
                                                            <br>
                                                            <div><b>Telephone</b></div>
                                                            <div style="background-color: #fff;padding: 5px;">
                                                                <div class="telephone"></div>
                                                            </div>
                                                            <br>
                                                            <div><b>Occupation</b></div>
                                                            <div style="background-color: #fff;padding: 5px;">
                                                                <div class="occupation"></div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div><b>Postcode</b></div>
                                                            <div style="background-color: #fff;padding: 5px;">
                                                                <div class="postcode"></div>
                                                            </div>
                                                            <br>
                                                            <div><b>Email</b></div>
                                                            <div style="background-color: #fff;padding: 5px;">
                                                                <div class="email"></div>
                                                            </div>
                                                            <br>
                                                            <div><b>Start Date</b></div>
                                                            <div style="background-color: #fff;padding: 5px;">
                                                                <div class="sdate"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <div id="declaration" class="dec-footer">
                                                <h4>Declaration</h4>
                                                <p>By applying for this insurance I understand and agree that I am responsible for providing complete and accurate information.</p>
                                                <p>When taking out my Policy I understand that it is important I ensure all statements made on my proposal form, over the telephone, on claim forms and other documents are full and accurate. In deciding to accept this policy and in setting the terms and premium, the insurer relies on the information I provide in this form.</p>
                                                <p>I understand that I have the statutory right to cancel this plan within 30days from the plan start date. I am applying on behalf of all applicants to be covered by this insurance and am doing so with their consent.</p>
                                                <p>I understand that with this moratorium method there is no need to provide the insurer with complete health information but I accept that any medical conditions for which I have suffered symptoms, sought or received medical advice or treatment or taken medication, prescribed or not, in the last 5 years will be excluded from the policy.</p>
                                                <p>This means the insurer would consider claims for any medical conditions suffered in the 5 years before the policy started provided that no symptoms have occurred, no medical advice or treatment has been sought or received and no medication, prescribed or not, has been taken for those conditions for a period of two continuous years after taking out the policy.</p>
                                                <p>I am a UK resident and am registered with a UK General Practitioner.</p>
                                                <p>Tick here to confirm your acceptance of these terms: <input type="checkbox" name="data-resident" value="Yes" /></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="row">
                                            <button type="button" class="btn prev-step btn-default stepone btn-lg" style="margin: 0 15px">Back</button>
                                            <span id="button-to-last-outer" class="pull-right"><button type="button" id="button-to-last" class="btn btn-primary btn-info-full next-step btn-lg" disabled>Click to Continue</button></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" role="tabpanel" id="complete">
                            <div class="container-right">
                                <div class="row1-right">
                                    <h3>Fully comprehensive medical insurance cover for you and
                                        your family</h3>
                                    <p>Essentials includes:</p>
                                    <ul>
                                        <li>Full inpatient and outpatient benefits</li>
                                        <li>Fast access to specialists and treatment</li>
                                        <li>Choice of over 1200 medical centres of excellence and hospitals</li>
                                        <li>Life insurance ‘Double Cover’ lump sum</li>
                                        <li>Many additional benefits and</li>
                                        <li>Dedicated customer service and claims team</li>
                                        <li>And, Essentials is surprisingly affordable</li>
                                    </ul>
                                </div>
                                <div class="row2-right">
                                    <h3>Important Information:</h3>
                                    <p>Essentials brochure</p>
                                    <p>Essentials Key Facts - Product Summary</p>
                                    <p>Essentials Members Guide & Policy Document</p>
                                    <p>EduHealth Key Facts</p>
                                </div>
                                <div class="row3-right">
                                    <h3>Contact Us:</h3>
                                    <p><b>T: 0345 266 9938</b></p>
                                    <p><b>E:</b> Info@EduHealth.co.uk</p>
                                    <p><b>A:</b> Sadler's House, 4-6 South Parade, Bawtry, South Yorkshire DN10 6JH</p>
                                </div>
                            </div>
                            <div class="step44 jumbotron first container-left" style="padding-left: 5px; padding-right: 5px;">
                                <h3 style="margin-left: 0;">Your Payment Choices</h3>
                                <div class="row" style="margin-left: 0;margin-right: 0;">
                                    <table width="100%">
                                        <tr>
                                            <td style="padding-top: 4px; width: 60%">
                                                <b>Your Monthly premium is: &pound;<span class="excess-data-month"></span></b>
                                            </td>
                                            <td class="text-center" style="width: 40%;">
                                                <div class="btn btn-lg btn-primary" id="pay-monthly" style="width: 240px;">Monthly Payment</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                or you can pay annually and <b>SAVE 5%</b>
                                            </td>
                                            <td class="text-center">
                                                <b>OR</b>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <b>if you chose annual payment your premium is: &pound;<span class="excess-data-year"></span></b>
                                            </td>
                                            <td class="text-center" style="width: 50%;">
                                                <div class="btn btn-lg btn-primary" id="pay-annual" style="width: 240px;">Annual Payment</div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="step44 jumbotron second container-left" style="padding-left: 5px; padding-right: 5px;">
                                <h3 style="margin-left: 0;">Confirmation</h3>
                                <div class="row">
                                    <div class="col-md-12" style="margin-left: 0;margin-right: 0;">
                                        <b>You have chosen to pay <span class="paywhat"></span> by Direct Debit your premium is: &pound;<span class="pay-bill"></span> <br><br>Please confirm the following:</b>
                                    </div>
                                    <ul style="list-style: none;">
                                        <li>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    Is the account in your name? 
                                                </div>
                                                <div class="col-md-6"><a href="#" class="say-yes yes-one">Yes</a> &nbsp;&nbsp;&nbsp;<a href="#" class="say-no no-one">No</a></div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    Are you the only signatory required to authorise this Direct Debit
                                                </div>
                                                <div class="col-md-6"><a href="#" class="say-yes yes-two">Yes</a> &nbsp;&nbsp;&nbsp;<a href="#" class="say-no no-two">No</a></div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="step44 jumbotron three container-left" style="padding: 5px;">
                                <h3>Your Direct Debit Details</h3>
                                <div class="row">
                                    <div class="col-md-12"><br>
                                        <center><i>Please complete the following. Your account details can be found on your bank statement or cheque book. All ﬁelds are required except where marked optional.</i></center>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <ol style="font-weight: bold;">
                                            <li>Name(s) of Account Holder(s)</li>
                                            <ol style="font-weight: normal;list-style: none;">
                                                <li style="margin-bottom: 3px">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            Account Holder 1
                                                        </div>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control finalfield" name="account-holder1" required>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            Account Holder 2
                                                        </div>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="account-holder2">
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                            <li> Bank or Building Society Account Number</li>
                                            <ol style="font-weight: normal;list-style: none;">
                                                <li>
                                                    <div class="row">
                                                        <div class="col-md-8 col-md-offset-4">
                                                            <table class="table">
                                                                <tr>
                                                                    <td style="padding-left: 0">
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="one1" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="one2" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="one3" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="one4" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="one5" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="one6" required>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="one7" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="one8" required>
                                                                    </td>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                            <li>  Branch Sort Code</li>
                                            <ol style="font-weight: normal;list-style: none;">
                                                <li>
                                                    <div class="row">
                                                        <div class="col-md-8 col-md-offset-4">
                                                            <table class="table">
                                                                <tr>
                                                                    <td style="padding-left: 0">
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="two1" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="two2" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="two3" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="two4" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="two5" required>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control finalfield" maxlength="1" name="two6" required>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                            <li> Direct Debit Date: <span style="font-weight: normal;">2nd day of the month</span></li>
                                        </ol>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary btn-info-full next-step btn-lg pull-right finalfield-submit" style="margin: 0">Click To Complete</button>
                                    </div>
                                </div>
                            </div>
                            <div class="row container-left" style="background: transparent; border: none;">
                                <div class="col-md-12" style="padding-left: 0;">
                                    <button type="button" class="btn prev-step btn-default btn-lg stepone" style="margin-left: 0">Back</button>
                                    <input type="hidden" name="whichplan" value="">
                                    <input type="hidden" name="monthly" value="">
                                    <input type="hidden" name="annual" value="">
                                    <input type="hidden" name="paytype" value="">

                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </form>
            </div>
        </section>
    </div>
</div> 

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/html.js"></script>
<script type="text/javascript" src="js/bootstrap-datepicker.min.js"></script>

<script type="text/javascript">
                                        $(function () {
                                            // register jQuery extension
                                            jQuery.extend(jQuery.expr[':'], {
                                                focusable: function (el, index, selector) {
                                                    return $(el).is('a, button, :input, [tabindex]');
                                                }
                                            });

                                            $(document).on('keypress', 'input,select', function (e) {
                                                if (e.which == 13) {
                                                    e.preventDefault();
                                                    // Get all focusable elements on the page
                                                    var $canfocus = $(':focusable');
                                                    var index = $canfocus.index(this) + 1;
                                                    if (index >= $canfocus.length)
                                                        index = 0;
                                                    $canfocus.eq(index).focus();
                                                }
                                            });
                                            $("#add").click(function () {
                                                var data = '<tr> \
                    <td> \
                        <dv class="form-group">\
                            <select name="data-titlef[]" class="form-control input-sm" placeholder="Title">\
                                <option value="Mr.">Mr.</option>\
                                <option value="Mrs.">Mrs.</option>\
                                <option value="Ms.">Ms.</option>\
                                <option value="Miss">Miss</option>\
                                <option value="Dr.">Dr.</option>\
                                <option value="Prof">Prof</option>\
                                <option value="Sir">Sir</option>\
                                <option value="Dame">Dame</option>\
                            </select>\
                        </dv>\
                    </td>\
                    <td>\
                        <dv class="form-group">\
                            <input name="data-fnamef[]" class="form-control input-sm" placeholder="Firstname" type="text">\
                        </dv>\
                    </td>\
                    <td>\
                        <dv class="form-group">\
                            <input name="data-lnamef[]" class="form-control input-sm" placeholder="surname" type="text">\
                        </dv>\
                    </td>\
                    <td>\
                        <table>\
                        <tr>\
                        <td>\
                        <div class="form-group">\
                                <select name="data-dob-ddf[]" class="form-control input-sm" style="padding: 5px;">\
<?php
for ($i = 1; $i < 32; $i++)
    echo "<option value=" . $i . ">" . $i . "</option>";
?>\
                                </select>\
                        </div>\
                        </td>\
                        <td>\
                        <div class="form-group">\
                            <select name="data-dob-mmf[]" class="form-control input-sm" style="padding: 5px;">\
                            <option value="1">January</option>\
                            <option value="2">February</option>\
                            <option value="3">March</option>\
                            <option value="4">April</option>\
                            <option value="5">May</option>\
                            <option value="6">June</option>\
                            <option value="7">July</option>\
                            <option value="8">August</option>\
                            <option value="9">September</option>\
                            <option value="10">October</option>\
                            <option value="11">November</option>\
                            <option value="12">December</option>\
                            </select>\
                        </div>\
                        </td>\
                        <td>\
                        <div class="form-group">\
                                <select name="data-dobf[]" class="form-control input-sm" style="padding: 5px;">\
<?php
for ($i = Date("Y"); $i > 1899; $i--)
    echo "<option value=" . $i . ">" . $i . "</option>";
?>\
                                </select>\
                        </div>\
                        </td>\
                        </tr>\
                        </table>\
                    </td>\
                    <td>\
                        <dv class="form-group">\
                            <select name="data-relationf[]" class="form-control input-sm" placeholder="relation">\
                                <option value="Partner">Partner</option>\
                                <option value="Spouse">Spouse</option>\
                                <option value="Child">Child</option>\
                            </select>\
                        </dv>\
                    </td>\
                    <td>\
                        <dv class="form-group">\
                            <select name="data-genderf[]" class="form-control input-sm" placeholder="Gender">\
                                <option value="Male">Male</option>\
                                <option value="Female">Female</option>\
                            </select>\
                        </dv>\
                    </td>\
                    <td>\
                        <dv class="form-group">\
                            <span class="glyphicon glyphicon-minus delete"> </span>\
                        </dv>\
                    </td>\
                </tr>';
                                                $(".family").append(data);
                                            });

                                            $(document).on("click", ".delete", function () {
                                                $(this).closest("tr").remove();
                                            });


                                            function reset() {
                                                $("#myForm").reset();
                                            }

                                        });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        //Initialize tooltips
        $('.nav-tabs > li a[title]').tooltip();

        //Wizard
        $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {

            var $target = $(e.target);

            if ($target.parent().hasClass('disabled')) {
                return false;
            }
        });
        function datec(date) {
            var datearray = date.split("/");

            var newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
            return newdate;
        }
        function validateEmail(email) {
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }
        $(".next-step").click(function (e) {
            var a = new Date();
            var b = new Date($("[name=data-dob]").val());
            var c = new Date(datec($("[name=data-sdate]").val()));
            var age = a.getFullYear() - b.getFullYear() + 1;
            var sdate = a.getTime() - c.getTime();
            $('html body').scrollTop(0);
            $('[required=required]').each(function () {
                if (!$(this).val()) {
                    has_empty = true;
                    return false;
                } else
                    has_empty = false;
            });
            if (has_empty) {
                alert("All fields are required");
            } else if (!validateEmail($("[name=data-email]").val())) {
                alert("Not valid email.");
            } else if (age > 0 && sdate < 0) {
                {
                    var $active = $('.wizard .nav-tabs li.active');
                    $active.next().removeClass('disabled');
                    nextTab($active);
                }
            } else {
                alert("Birthdate OR Starttime Error.")
            }

        });
        $(".prev-step").click(function (e) {

            var $active = $('.wizard .nav-tabs li.active');
            prevTab($active);

        });
    });

    function nextTab(elem) {
        $(elem).next().find('a[data-toggle="tab"]').click();
    }
    function prevTab(elem) {
        $(elem).prev().find('a[data-toggle="tab"]').click();
    }


    $(document).ready(function () {
        $('.finalfield-submit').click(function () {
            $('.finalfield').each(function () {
                if (!$(this).val()) {
                    alert("All fields are required");
                    return false;
                }
            });
        });
        $('.finalfield').on('input', function() {
            $(this).parent().next().children('.finalfield').select();
        });
    });


//according menu

    $(document).ready(function ()
    {
        //Add Inactive Class To All Accordion Headers
        $('.accordion-header').toggleClass('inactive-header');

        //Set The Accordion Content Width
        var contentwidth = $('.accordion-header').width();
        $('.accordion-content').css({});

        //Open The First Accordion Section When Page Loads
        $('.accordion-header').first().toggleClass('active-header').toggleClass('inactive-header');
        $('.accordion-content').first().slideDown().toggleClass('open-content');

        // The Accordion Effect
        $('.accordion-header').click(function () {
            if ($(this).is('.inactive-header')) {
                $('.active-header').toggleClass('active-header').toggleClass('inactive-header').next().slideToggle().toggleClass('open-content');
                $(this).toggleClass('active-header').toggleClass('inactive-header');
                $(this).next().slideToggle().toggleClass('open-content');
            } else {
                $(this).toggleClass('active-header').toggleClass('inactive-header');
                $(this).next().slideToggle().toggleClass('open-content');
            }
        });

        return false;
    });
</script>
