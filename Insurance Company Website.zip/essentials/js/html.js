$(function () {
    $('.date').datepicker({
        format: 'dd/mm/yyyy',
        startDate: '0d',
        autoclose: true
    });


    function datec(date) {
        var datearray = date.split("/");

        var newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
        return newdate;
    }
    var title;
    var fname;
    var lname;
    var dob;
    var check = 0;
    var a;
    var b;
    var c;
    var d;
    var age;
    var agei;
    var gender;
    var occupation;
    var telephone;
    var email;
    var postcode;
    var address;
    var sdate;
    var excesstype;
    var passport = [];
    var passportarray = [];
    var passportplusarray = [];
    var passportplus;
    var titlef = [];
    var fnamef = [];
    var lnamef = [];
    var dobf = [];
    var dobddf = [];
    var dobmmf = [];
    var relationf = [];
    var genderf = [];
    var option;
    $(document).on("click", ".two-yes,.height-weight,.one-four-five", function (e) {
        e.preventDefault();
        $($(this).parent()).siblings(":last").children().slideDown();
        if ($(this).siblings(":last").hasClass("comp")) {
            if ($(this).siblings(":last").hasClass("red"))
                check--;
        }
        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
        } else {
            $(this).addClass("red");
        }
        $(this).siblings(":last").removeClass("red");
    });
    var sayc = 0;
    $(document).on("keyup", '[name^="data-exact"],[name^="data-symptoms"],[name^="data-treatment"],[name^="data-otreatment"],[name^="data-relation"],[name^="data-recovery"],[name^="data-des"],[name^="data-name"],[name^="data-relation"],[name^="data-height"],[name^="data-weight"],[name^="data-smoke"],[name^="data-glass"]', function () {
        var name = $(this).attr('name').split("[]");
        var d = $(this).attr(name[0]);
        $("[" + name[0] + "^=" + d + "]").val($(this).val());
        //alert(d);
    });
    function data() {
        title = $("[name=data-title]").val();
        fname = $("[name=data-fname]").val();
        lname = $("[name=data-lname]").val();
        dob = $("[name=data-dob-dd]").val() + "/" + $("[name=data-dob-mm]").val() + "/" + $("[name=data-dob]").val();
        gender = $("[name=data-gender]").val();
        occupation = $("[name=data-occupation]").val();
        telephone = $("[name=data-telephone]").val();
        email = $("[name=data-email]").val();
        postcode = $("[name=data-postcode]").val();
        address = $("[name=data-address]").val();
        sdate = datec($("[name=data-sdate]").val());
        excesstype = $("[name=data-excesstype]").val();
        c = new Date(sdate);
        a = new Date(dob);
        d = new Date();
        age = d.getFullYear() - a.getFullYear();
        passportarray = [["17", "16.23", "184.96"],
            ["18", "16.84", "191.93"], ["19", "17.68", "201.61"],
            ["20", "18.56", "211.64"], ["21", "19.48", "222.04"],
            ["22", "20.42", "232.80"], ["23", "21.41", "244.06"],
            ["24", "22.43", "255.67"], ["25", "23.47", "267.53"],
            ["26", "24.48", "279.15"], ["27", "24.93", "284.18"],
            ["28", "25.31", "288.46"], ["29", "26.23", "298.98"],
            ["30", "27.10", "309.01"], ["31", "27.86", "317.57"],
            ["32", "28.55", "325.41"], ["33", "29.26", "333.59"],
            ["34", "30.05", "342.53"], ["35", "30.86", "351.71"],
            ["36", "31.70", "361.37"], ["37", "32.53", "370.91"],
            ["38", "33.42", "380.94"], ["39", "34.32", "391.22"],
            ["40", "35.26", "401.99"], ["41", "36.29", "413.73"],
            ["42", "37.39", "426.33"], ["43", "38.54", "439.41"],
            ["44", "39.76", "453.25"], ["45", "40.94", "466.71"],
            ["46", "42.20", "481.13"], ["47", "43.44", "495.20"],
            ["48", "44.76", "510.36"], ["49", "46.18", "526.40"],
            ["50", "47.56", "542.18"],
            ["51", "49.22", "561.14"], ["52", "50.93", "580.59"],
            ["53", "52.76", "601.39"], ["54", "54.59", "622.30"],
            ["55", "56.51", "644.20"], ["56", "58.49", "666.83"],
            ["57", "60.52", "689.96"], ["58", "62.60", "713.69"],
            ["59", "64.80", "738.76"], ["60", "67.05", "764.34"],
            ["61", "70.09", "799.07"], ["62", "73.22", "834.79"],
            ["63", "76.56", "872.85"], ["64", "80.03", "912.36"],
            ["65", "83.69", "954.07"], ["66", "87.50", "997.50"],
            ["67", "91.54", "1043.62"], ["68", "95.78", "1091.83"],
            ["69", "100.12", "1141.37"], ["70", "104.70", "1193.60"],
            ["71", "109.43", "1247.55"], ["72", "114.38", "1303.95"],
            ["73", "119.57", "1363.16"], ["74", "124.95", "1424.44"],
            ["75", "130.64", "1489.41"], ["76", "136.60", "1557.31"],
            ["77", "142.86", "1628.62"], ["78", "150.51", "1715.73"],
            ["79", "158.32", "1804.78"],
            ["80", "162.87", "1856.78"]];

        passportplusarray = [["17", "14.61", "166.49"],
            ["18", "15.03", "171.38"], ["19", "15.81", "180.19"],
            ["20", "16.62", "189.49"],
            ["21", "17.47", "199.16"], ["22", "18.33", "208.95"],
            ["23", "19.23", "219.22"], ["24", "20.18", "230.10"],
            ["25", "21.12", "240.75"], ["26", "22.04", "251.26"],
            ["27", "22.46", "256.04"], ["28", "22.79", "259.71"],
            ["29", "23.60", "269.00"], ["30", "24.41", "278.18"],
            ["31", "25.05", "285.65"], ["32", "25.67", "292.61"],
            ["33", "26.36", "300.45"], ["34", "27.05", "308.28"],
            ["35", "27.78", "316.72"], ["36", "28.52", "325.16"],
            ["37", "29.27", "333.72"], ["38", "30.05", "342.53"],
            ["39", "30.86", "351.71"], ["40", "31.70", "361.37"],
            ["41", "32.64", "372.13"], ["42", "33.64", "383.51"],
            ["43", "34.67", "395.25"], ["44", "35.77", "407.86"],
            ["45", "36.86", "420.21"], ["46", "37.96", "432.82"],
            ["47", "39.11", "445.91"], ["48", "40.29", "459.24"],
            ["49", "41.54", "473.55"], ["50", "42.83", "488.23"],
            ["51", "44.31", "505.24"], ["52", "45.84", "522.60"],
            ["53", "47.48", "541.20"], ["54", "49.12", "560.04"],
            ["55", "50.87", "579.97"], ["56", "52.61", "599.80"],
            ["57", "54.47", "620.84"], ["58", "56.35", "642.37"],
            ["59", "58.33", "665.00"], ["60", "60.35", "687.88"],
            ["61", "63.08", "719.19"], ["62", "65.94", "751.74"],
            ["63", "68.92", "785.74"], ["64", "72.05", "821.34"],
            ["65", "75.33", "858.66"], ["66", "78.74", "897.68"],
            ["67", "82.39", "939.27"], ["68", "86.19", "982.58"],
            ["69", "90.14", "1027.60"], ["70", "94.26", "1074.57"],
            ["71", "98.47", "1122.65"], ["72", "102.96", "1173.79"],
            ["73", "107.62", "1226.87"], ["74", "112.45", "1281.93"],
            ["75", "117.58", "1340.40"], ["76", "122.94", "1401.45"],
            ["77", "128.55", "1465.55"], ["78", "135.46", "1544.22"],
            ["79", "142.46", "1623.98"], ["80", "146.60", "1671.19"]];
    }
    $(document).on("click", "#b1", function () {
        $("#3b").hide();
        $("#3a").show();
        option = 1;
    });
    $(document).on("click", "#b2", function () {
        $("#3a").hide();
        $("#3b").show();
        option = 2;
    });
    $(document).on("click", ".select-no", function (e) {
        e.preventDefault();
        //alert("You cannot select no");

        $(this).siblings().removeClass("red");
        $($(this).parent()).siblings(":last").children().slideUp();
        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
            if ($(this).hasClass("comp")) {
                check--;
            }
        } else {
            $(this).addClass("red");
            if ($(this).hasClass("comp")) {
                check++;
            }
        }
        //alert(check);
    });

    $(document).on("click", "#button-to-last", function () {

        option = 1;
        if (excesstype === 'NIL') {
            $(".passport-m").html(passport[1]);
            $(".passport-y").html(passport[2]);
            $("[name=whichplan]").val("Essentials");
            $("[name=monthly]").val(passport[1]);
            $("[name=annual]").val(passport[2]);
        } else if (excesstype === '£100') {
            $(".passport-m").html(parseFloat(passportplus[1]).toFixed(2));
            $(".passport-y").html(parseFloat(passportplus[2]).toFixed(2));
            $("[name=whichplan]").val("Essentials");
            $("[name=monthly]").val(parseFloat(passportplus[1]).toFixed(2));
            $("[name=annual]").val(parseFloat(passportplus[2]).toFixed(2));
        }
        $(".first").show();
        $(".second,.three").hide();
    });
    $(document).on("click", "#pay-monthly", function () {
        $(".first").hide();
        $("[name=paytype]").val("Monthly");
        if (excesstype === 'NIL') {
            $(".paywhat").html("<b>Monthly</b>");
            $(".pay-bill").html(parseFloat(passport[1]).toFixed(2));
        } else if (excesstype === '£100') {
            $(".paywhat").html("<b>Monthly</b>");
            $(".pay-bill").html(parseFloat(passportplus[1]).toFixed(2));
        }
        $(".second").show();
    });

    $(document).on("click", "#pay-annual", function () {
        $(".first").hide();
        $("[name=paytype]").val("Annual");
        if (excesstype === 'NIL') {
            $(".paywhat").html("<b>Annual</b>");
            $(".pay-bill").html(parseFloat(passport[2]).toFixed(2));
        } else if (excesstype === '£100') {
            $(".paywhat").html("<b>Annual</b>");
            $(".pay-bill").html(parseFloat(passportplus[2]).toFixed(2));
        }
        $(".second").show();
    });
    ///var sayc = 0;
    var yes_one = 0;
    var yes_two = 0;
    $(document).on("click", ".yes-one", function () {
        yes_one = 1;
    });
    $(document).on("click", ".no-one", function () {
        yes_one = 0;
    });
    $(document).on("click", ".yes-two", function () {
        yes_two = 1;
    });
    $(document).on("click", ".no-two", function () {
        yes_two = 0;
    });
    $(document).on("click", ".say-yes", function (e) {
        e.preventDefault();

        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
            sayc--;
        } else {
            $(this).addClass("red");
            sayc++;
        }
        $(this).siblings().removeClass("red");
        if (Number(yes_one) + Number(yes_two) == 2) {
            $(".two").hide();
            $(".three").show();
        }
    });

    $(document).on("click", ".say-no", function (e) {
        e.preventDefault();
        if (Number(yes_one) + Number(yes_two) != 2) {

            $(".two").show();
            $(".three").hide();
        }
        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
            sayc++;
        } else {
            $(this).addClass("red");
            sayc--;
        }
        $(this).siblings().removeClass("red");
        alert("You must be the policyholder and/ or authorised signatory and/or the sole signatory of this account to progress with this application");
    });
    Array.prototype.SumArray = function (arr) {
        var sum = [];
        if (arr != null && this.length == arr.length) {
            for (var i = 0; i < arr.length; i++) {
                sum.push(Number(this[i]) + Number(arr[i]));
            }
        }
        return sum;
    }
    $(document).on("change", "[name=excess-type]", function () {
        var value = $(this).val();
        $("[name=data-excesstype]").val(value);
        $("#button-to-2nd-last").removeAttr("disabled");
        $("[name=excess-type]").parent().children(".radio-checkbox").children("i").hide();
        $(this).parent().children(".radio-checkbox").children("i").show();
    });
    $(document).on("change", "[name=data-resident]", function () {
        if ($(this).is(":checked"))
            $("#button-to-last").removeAttr("disabled");
        else {
            $("#button-to-last").attr("disabled", "");
            alert("You must confirm your acceptance of the Declaration before proceeding");
        }
    });
    $(document).on("click", "#button-to-2nd-last-outer", function () {
        if ($(this).children("#button-to-2nd-last").is(":disabled")) {
            alert("You select excess first before proceeding");
        }
    });
    $(document).on("click", "#button-to-last-outer", function () {
        if ($(this).children("#button-to-last").is(":disabled")) {
            alert("You must confirm your acceptance of the Declaration before proceeding");
        }
    });
    $(document).on("click", ".stepone", function () {
        data();
        if (age < 17)
            agei = 17;
        else
            agei = age;
        for (var i = 0, len = passportarray.length; i < len; i++) {
            if (passportarray[i][0] == agei) {
                passport = passportarray[i];
                passportplus = passportplusarray[i];
                break;
            }
        }

        $(".title").html(title);
        $(".fname").html(fname);
        $(".lname").html(lname);
        $(".dob").html(dob);
        $(".gender").html(gender);
        $(".occupation").html(occupation);
        $(".address").html(address);
        $(".postcode").html(postcode);
        $(".telephone").html(telephone);
        $(".email").html(email);
        $(".sdate").html(datec(sdate));
        $(".excesstype").html(excesstype);
        a = new Date();
        b = new Date(sdate);
        if ((a.getTime() - b.getTime()) < 0) {
            titlef = [];
            fnamef = [];
            lnamef = [];
            dobf = [];
            relationf = [];
            genderf = [];
            dobmmf = [];
            dobddf = [];
            $('[name^="data-titlef"]').each(function () {
                titlef.push($(this).val());
            });
            $('[name^="data-fnamef"]').each(function () {
                fnamef.push($(this).val());
            });
            $('[name^="data-lnamef"]').each(function () {
                lnamef.push($(this).val());
            });
            $('[name^="data-dob-mmf"]').each(function () {
                dobmmf.push($(this).val());
            });
            $('[name^="data-dob-ddf"]').each(function () {
                dobddf.push($(this).val());
            });
            $('[name^="data-dobf"]').each(function () {
                dobf.push($(this).val());
                a = new Date();
                var agefa = 0;
                agefa = a.getFullYear() - $(this).val();
                if (agefa < 17)
                    ageii = 17;
                else
                    ageii = agefa;
                for (var i = 0, len = passportarray.length; i < len; i++) {
                    if (passportarray[i][0] == ageii) {
                        passport = passport.SumArray(passportarray[i]);
                        passportplus = passportplus.SumArray(passportplusarray[i]);
                        break;
                    }
                }
                passport[0] = passport[0] - ageii;
                passportplus[0] = passportplus[0] - ageii;
            });
            $('[name^="data-relationf"]').each(function () {
                relationf.push($(this).val());
            });
            $('[name^="data-genderf"]').each(function () {
                genderf.push($(this).val());
            });
            var member_list = " ";
            for (i = 0; i < titlef.length; i++) {
                member_list += "<tr>\
				<td>" + titlef[i] + "</td>\
				<td>" + fnamef[i] + "</td>\
				<td>" + lnamef[i] + "</td>\
				<td>" + dobddf[i] + "/" + dobmmf[i] + "/" + dobf[i] + "</td>\
				<td>" + relationf[i] + "</td>\
				<td>" + genderf[i] + "</td>\
			</tr>";
            }
            $(".family-members").html(member_list);
            //alert((240).toFixed(2))

            //alert(passport.toFixed(2));
            //alert(passportplus);
            $(".passport-data-month").html(parseFloat(passport[1]).toFixed(2));
            $(".passport-data-month-first").html(parseFloat(passport[1]).toFixed(2));
            //alert(passport[1]);
            $(".passport-data-year").html(parseFloat(passport[2]).toFixed(2));

            //alert(passportplus.toFixed(2));
            $(".passportplus-data-month").html(parseFloat(passportplus[1]).toFixed(2));
            $(".passportplus-data-month-first").html(parseFloat(passportplus[1]).toFixed(2));
            //alert(passportplus[1]);
            $(".passportplus-data-year").html(parseFloat(passportplus[2]).toFixed(2));

            if (excesstype === 'NIL') {
                //alert(passport.toFixed(2));
                $(".excess-data-month").html(parseFloat(passport[1]).toFixed(2));
                $(".excess-data-month-first").html(parseFloat(passport[1]).toFixed(2));
                //alert(passport[1]);
                $(".excess-data-year").html(parseFloat(passport[2]).toFixed(2));
            } else if (excesstype === '£100') {
                //alert(passportplus.toFixed(2));
                $(".excess-data-month").html(parseFloat(passportplus[1]).toFixed(2));
                $(".excess-data-month-first").html(parseFloat(passportplus[1]).toFixed(2));
                //alert(passportplus[1]);
                $(".excess-data-year").html(parseFloat(passportplus[2]).toFixed(2));
            }
            //alert(passport);
        }

    });

    $("#b2").click(function () {
        var append = '<hr>\
                                                	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2">Name</div>\
                                                			<div class="col-md-2">Relationship to policyholder</div>\
                                                			<div class="col-md-2">Height</div>\
                                                			<div class="col-md-2">Weight</div>\
                                                			<div class="col-md-2">If smoker. No. per day?</div>\
                                                			<div class="col-md-2">Alcohol No. of  glasses per week:  beer/wine/spirits per week</div>\
                                                		</div>\
                                                	</li>\
                                                	';

        var append1 = '<hr> \
                                                	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2">Name</div>\
                                                			<div class="col-md-2">Relationship to policyholder</div>\
                                                			<div class="col-md-8">If YES to questions 1.4 and/or 1.5 then please answer below</div>\
                                                		</div>\
                                                	</li>';
        append += '<li> \
            <div class="row">\
                <div class="col-md-2"><input type="text" class="form-control" disabled name="data-name[]" value="' + fname + ' ' + lname + '"></div>\
                <div class="col-md-2"><input name="data-relation[]" data-relation="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-height[]" data-height="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-weight[]" data-weight="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-smoke[]" data-smoke="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input type="text" data-glass="-1" name="data-glass[]" class="form-control"></div>\
            </div>\
        </li>';
        append1 += '   	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input type="text" name="data-name[]" disabled value="' + fname + ' ' + lname + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-relation[]" data-height="-1" type="text" disabled class="form-control"></div>\
                                                			<div class="col-md-8"><textarea name="data-des[]" data-des="-1" class="form-control"></textarea></div>\
                                                		</div>\
                                                	</li>';
        var append2 = '<hr>\
                                                	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2">Name</div>\
                                                			<div class="col-md-2">Exact diagnosis (describe the health condition and tests if no diagnosis</div>\
                                                			<div class="col-md-2">When did symptoms start and ﬁnish?</div>\
                                                			<div class="col-md-2">Treatment (medication, surgery, hospitalisation…)</div>\
                                                			<div class="col-md-2">Has there been a complete recovery?</div>\
                                                			<div class="col-md-2">Ongoing treatment</div> \
                                                		</div>\
                                                	</li>';
        append2 += '<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input name="data-name[]" type="text" disabled value="' + fname + ' ' + lname + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-exact[]" data-exact="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-symptoms[]" data-symptoms="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-treatment[]" data-treatment="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-recovery[]" data-recovery="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-otreatment[]" data-otreatment="-1" type="text" class="form-control"></div>\
                                                		</div>\
                                                	</li>';
        for (i = 0; i < titlef.length; i++) {
            append += '<li> \
            <div class="row">\
                <div class="col-md-2"><input type="text" class="form-control" disabled name="data-name[]" value="' + fnamef[i] + ' ' + lnamef[i] + '"></div>\
                <div class="col-md-2"><input name="data-relation[]" data-relation="' + i + '" type="text" disabled class="form-control" value="' + relationf[i] + '"></div>\
                <div class="col-md-2"><input name="data-height[]" data-height="' + i + '" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-weight[]" data-weight="' + i + '" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-smoke[]" data-smoke="' + i + '" type="text" class="form-control"></div>\
                <div class="col-md-2"><input type="text" data-glass="' + i + '" name="data-glass[]" class="form-control"></div>\
            </div>\
        </li>';

            append1 += '                                    	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input type="text" name="data-name[]" disabled value="' + fnamef[i] + ' ' + lnamef[i] + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input type="text" data-relation="' + i + '" name="data-relation[]" disabled value="' + relationf[i] + '" class="form-control"></div>\
                                                			<div class="col-md-8"><textarea name="data-des[]" data-des="' + i + '" class="form-control"></textarea></div>\
                                                		</div>\
                                                	</li>';
            append2 += '<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input name="data-name[]" type="text" disabled value="' + fnamef[i] + ' ' + lnamef[i] + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-exact[]" data-exact="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-symptoms[]" data-symptoms="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-treatment[]" data-treatment="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-recovery[]" data-recovery="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-otreatment[]" data-otreatment="' + i + '" type="text" class="form-control"></div>\
                                                		</div>\
                                                	</li>';

        }
        append += "<hr>";
        append1 += "<hr>";
        append2 += "<hr>";
        $(".height-weight-table").html(append);
        $(".one-four-five-table").html(append1);
        $(".two-one-to-6-table").html(append2);
    });
});