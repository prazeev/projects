<?php

if (!isset($_POST['data-fname'])) {
    header('Location: dab.php');
}

require_once('tcpdf/tcpdf.php');


$data = array();
$data['title'] = $_POST['data-title'];
$data['fname'] = $_POST['data-fname'];
$data['lname'] = $_POST['data-lname'];
$data['dob'] = $_POST['data-dob-dd'] . "-" . $_POST['data-dob-mm'] . "-" . $_POST['data-dob'];
$data['gender'] = $_POST['data-gender'];
$data['telephone'] = $_POST['data-telephone'];
$data['email'] = $_POST['data-email'];
$data['postcode'] = $_POST['data-postcode'];
$data['address'] = $_POST['data-address'];
$data['sdate'] = $_POST['data-sdate'];

if (isset($_POST['data-titlef'])) {
    $family = array();
    $family['title'] = $_POST['data-titlef'];
    $family['fname'] = $_POST['data-fnamef'];
    $family['lname'] = $_POST['data-lnamef'];
    $family['dobdd'] = $_POST['data-dob-ddf'];
    $family['dobmm'] = $_POST['data-dob-mmf'];
    $family['dobyy'] = $_POST['data-dobf'];
    $family['relation'] = $_POST['data-relationf'];
    $family['gender'] = $_POST['data-genderf'];
} else {
    $no_family = 1;
    $family = array();
    $family['title'] = '';
    $family['fname'] = '';
    $family['lname'] = '';
    $family['dobdd'] = '';
    $family['dobmm'] = '';
    $family['dobyy'] = '';
    $family['relation'] = '';
    $family['gender'] = '';
}


$plan['excesstype'] = $_POST['data-excesstype'];
$plan['whichplan'] = $_POST['whichplan'];
$plan['monthly'] = $_POST['monthly'];
$plan['annual'] = $_POST['annual'];
$plan['paytype'] = $_POST['paytype'];

$others['data-resident'] = (isset($_POST['data-resident']) ? "Yes" : "No");
$others['data-mailing'] = (isset($_POST['data-mailing']) ? "Yes" : "No");

/*
  //$one['name'] = $_POST['data-name'];
  $one['height'] = $_POST['data-height'];
  //$one['relation'] = $_POST['data-relation'];
  $one['weight'] = $_POST['data-weight'];
  $one['smoke'] = $_POST['data-smoke'];
  $one['glass'] = $_POST['data-glass'];

  $two['des'] = $_POST['data-des'];

  $three['exact'] = $_POST['data-exact'];
  $three['symptoms'] = $_POST['data-symptoms'];
  $three['treatment'] = $_POST['data-treatment'];
  $three['recovery'] = $_POST['data-recovery'];
  $three['otreatment'] = $_POST['data-otreatment'];

 */
$holderone = $_POST['account-holder1'];
$holdertwo = $_POST['account-holder2'];
$societyno = $_POST['one1'] . $_POST['one2'] . $_POST['one3'] . $_POST['one4'] . $_POST['one5'] . $_POST['one6'] . $_POST['one7'] . $_POST['one8'];
$branch = $_POST['two1'] . $_POST['two2'] . $_POST['two3'] . $_POST['two4'] . $_POST['two5'] . $_POST['two6'];






// String into pdf
$suson_user_title = $data['title'];
$suson_user_firstname = $data['fname'];
$suson_user_lastname = $data['lname'];
$suson_user_dob = $data['dob'];
$suson_user_gender = $data['gender'];
$suson_user_phone = $data['telephone'];
$suson_user_email = $data['email'];
$suson_user_postcode = $data['postcode'];
$suson_user_address = $data['address'];
list($suson_user_sdate_day, $suson_user_sdate_month, $suson_user_sdate_year) = split('/', $data['sdate']);
$suson_user_sdate = "$suson_user_sdate_day/$suson_user_sdate_month/$suson_user_sdate_year";
$suson_user_sdate_for_calc = "$suson_user_sdate_year/$suson_user_sdate_month/$suson_user_sdate_day";


$suson_policy_number = date("dmY") . '/' . $suson_user_postcode;

$suson_issued_date = date("d/m/Y");
$suson_renewal_date_year = date('Y', strtotime($suson_user_sdate_for_calc)) + 1;
$suson_renewal_date = date('d/m/', strtotime($suson_user_sdate_for_calc)) . $suson_renewal_date_year;

$total_no_of_family = count($family['fname']) - 1;
/*
  $suson_family_names = '';
  if (!isset($no_family)) {
  for ($suson_x = 0; $suson_x < $total_no_of_family; $suson_x++) {
  $suson_family_names .= $family['title'][$suson_x] . ' ' . $family['fname'][$suson_x] . ' ' . $family['lname'][$suson_x] . '<br>';
  }
  }
  $suson_family_names_without_title = '';
  if (!isset($no_family)) {
  for ($suson_x = 0; $suson_x < $total_no_of_family; $suson_x++) {
  $suson_family_names_without_title .= $family['fname'][$suson_x] . ' ' . $family['lname'][$suson_x] . '<br>';
  }
  }
  $suson_family_only_titles = '';
  if (!isset($no_family)) {
  for ($suson_x = 0; $suson_x < $total_no_of_family; $suson_x++) {
  $suson_family_only_titles .= $family['title'][$suson_x] . '<br>';
  }
  }
  $suson_family_dobs = '';
  if (!isset($no_family)) {
  for ($suson_x = 0; $suson_x < $total_no_of_family; $suson_x++) {
  $suson_family_dobs .= $family['dobyy'][$suson_x] . '/' . $family['dobmm'][$suson_x] . '/' . $family['dobdd'][$suson_x] . '<br>';
  }
  }
  $suson_family_no = '';
  if (!isset($no_family)) {
  for ($suson_x = 1; $suson_x < $total_no_of_family + 1; $suson_x++) {
  $suson_family_no .= date("dmY") . '/' . $suson_user_postcode . '/' . $suson_x . '<br>';
  }
  }
 */

$fam = array();
if (!isset($no_family)) {
    foreach ($family as $key => $value) {
        foreach ($value as $v => $k) {
            $fam[$v][$key] = $family[$key][$v];
        }
    }
}
$i = 0;
$suson_family_dobs = "";
$suson_family_names = "";
$suson_family_no = "";
$suson_family_names_without_title = "";
$suson_family_only_titles = "";

if (!isset($no_family)) {
    foreach ($fam as $key => $value) {
        $suson_family_names .= $value['title'] . " " . $value['fname'] . " " . $value['lname'] . "<br>";
        $suson_family_names_without_title .= $value['fname'] . " " . $value['lname'] . "<br>";
        $suson_family_only_titles .= $value['title'] . "<br>";
        $suson_family_dobs .= $value['dobdd'] . "/" . $value['dobmm'] . "/" . $value['dobyy'] . "<br>";
        $suson_family_no .= date("dmY") . '/' . $suson_user_postcode . '/' . ++$i . '<br>';
    }
}
//   var_dump($suson_family_no);
$suson_excesstype = $plan['excesstype'];
$suson_plan = $plan['whichplan'];
$suson_plan_monthly = $plan['monthly'];
$suson_plan_annual = $plan['annual'];
$suson_plan_paytype = $plan['paytype'];
if ($suson_plan_paytype == 'Annual') {
    $suson_plan_price = $suson_plan_annual;
} else {
    $suson_plan_price = $suson_plan_monthly;
}

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Edu Health');
$pdf->SetTitle('Policy Schedule');
$pdf->SetSubject('Policy Schedule');
$pdf->SetKeywords('Policy Schedule');

// remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(10, 10, 10);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
// ---------------------------------------------------------
// set font
$pdf->SetFont('times', '', 11);

// add a page
$pdf->AddPage();

// set some text to print
$txt = <<<EOD
        <style>
        .suson-logo {
            width: 150px;
        }
        .suson-header {
            font-size: 24px;
            font-weight: bold;
        }
        .suson-omgbox {
            background-color: #60a936;
            color: #fff;
            text-align: center;
            padding: 50%;
        }
        .suson-details {
            margin: 0
        }
        .suson-info-header {
            border: solid 1px #000;
            text-align: center;
            font-weight: bold;
        }
        .suson-footer {
            text-align: center;
        }
        </style>
        <table>
        <tr>
        <td>
        <img class="suson-logo" src="img/logo.png">
        <div class="suson-header">Policy Schedule</div>
        <div class="suson-details">$suson_user_title $suson_user_firstname $suson_user_lastname<br>$suson_user_address<br>$suson_user_postcode</div>
        </td>
        <td>
        <div class="suson-omgbox"><br>Your policy number is<br><strong>$suson_policy_number</strong><br>For CLAIMS call: 0333 577 7274<br>Please quote your policy number whenever you contact us.<br>You can call us Mon-Fri: 0800-1800 (excl. bank holidays)<br>Calls will be recorded and may be monitored<br>You can contact us in writing at:<br>EduHealth Claims, Healix House,<br>Esher Green, Esher, Surrey, KT10 8AB<br>eduhealth@healix.com<br>For CUSTOMER SERVICE call:<br><strong>0345 226 9938</strong><br></div>
        </td>
        </tr>
        </table>
        <div class="suson-date-issued"><strong>Date issued:</strong> $suson_issued_date</div>
        <br>This policy schedule is subject to the rules and benefits set out in your Members Guide & Policy Document and any variation noted below. Please read the Members Guide & Policy Document for a full explanation of what your terms and conditions mean.
        <div></div>
        <table>
        <tr>
        <td style="width: 20%"><strong>Policyholder:</strong></td>
        <td>$suson_user_title $suson_user_firstname $suson_user_lastname</td>
        </tr>
        <tr>
        <td><strong>Plan:</strong></td>
        <td>$suson_plan</td>
        </tr>
        <tr>
        <td><strong>Cover start date:</strong></td>
        <td>$suson_user_sdate</td>
        </tr>
        <tr>
        <td><strong>Renewal date:</strong></td>
        <td>$suson_renewal_date</td>
        </tr>
        </table>
        <br>
        <div><strong>Member details:</strong></div>
        <table border="1" style="border-collapse: collapse">
        <tr>
        <td><strong>Status</strong></td>
        <td><strong>Name</strong></td>
        <td><strong>Date of birth</strong></td>
        <td><strong>Member no</strong></td>
        </tr>
        <tr>
        <td>$suson_family_only_titles</td>
        <td>$suson_family_names_without_title</td>
        <td>$suson_family_dobs</td>
        <td>$suson_family_no</td>
        </tr>
        </table>
        <br>
        <div><strong>Acceptance terms:</strong></div>
        <table border="1" style="border-collapse: collapse">
        <tr>
        <td><strong>Name</strong></td>
        <td><strong>Underwriting type</strong></td>
        <td><strong>Underwriting start date</strong></td>
        </tr>
        <tr>
        <td>$suson_user_title $suson_user_firstname $suson_user_lastname<br>$suson_family_names</td>
        <td>Moratorium</td>
        <td>$suson_issued_date</td>
        </tr>
        </table>
        <div></div>
        <table>
        <tr>
        <td style="width: 20%"><strong>Hospital list:</strong></td>
        <td>National</td>
        </tr>
        <tr>
        <td><strong>Policy excess:</strong></td>
        <td>$suson_excesstype</td>
        </tr>
        <tr>
        <td><strong>Benefits of cover:</strong></td>
        <td>Please refer to the table of benefits in your Members Guide & Policy Document.</td>
        </tr>
        </table>
        <div></div>
        <table border="1" style="border-collapse: collapse">
        <tr>
        <td><strong>Premium payable</strong><br>Including insurance premium tax (IPT) at 9.5%</td>
        <td><strong>Payment frequency</strong></td>
        </tr>
        <tr>
        <td>£$suson_plan_price</td>
        <td>$suson_plan_paytype</td>
        </tr>
        </table>
        <div></div>
        <div class="suson-info-header">Data Protection and Confidentiality</div>
        <div><strong>Changes to Membership Information</strong><br>If you need to make changes to your policy details call EduHealth Policy Administration on 0345 226 9938. Please note that this number is for administration ONLY. For claims, please call 0333 577 7274.</div>
        <div><strong>Confidentiality</strong><br>EduHealth, and its claims administrator (Healix) and policy administrator (Trent-Services), fully comply with the Data Protection Legislation and Medical Confidentiality Guidelines.</div>
        <div><strong>Medical Information</strong><br>Medical information will be kept confidential and only disclosed to those involved in your treatment or care or in order to validate claims, including your GP and if applicable, to any person or organization who may be responsible for meeting your treatment expenses or their agents.</div>
        <div><strong>Member Details</strong><br>All membership documents and confirmation of how we have dealt with any claims you make will be sent to the principle member.</div>
        <div><strong>Telephone Calls</strong><br>In order to ensure continuous improvement of our service to members, your calls will be recorded and may be monitored.</div>
        <div><strong>EduHealth Claims Handling And Regulation</strong><br>Healix Health Services (Company Number 03945478) whose registered office is at Healix House, Esher Green, Esher, Surrey, KT10 8AB, is the appointed Claims Handler of the scheme.</div>
        <div><strong>Fraud</strong><br>sInformation may be disclosed to other relevant organizations in order to prevent fraudulent or improper claims or as required by law. We will not disclose it unless it is lawful to do so.</div>
        <div><strong>Contact Address</strong><br>If you have any Data Protection queries, please write to the Data Protection Manager at Healix House, Esher Green, Esher, Surrey, KT10 8AB</div>
        <div><strong>Policy Administrator</strong><br>Trent-Services (Administration) Ltd (Company Number 05297950) Trent House, Love Lane, Cirencester, Glos. GL7 1XD is the appointed Administrator of the scheme. Trent-Services are authorised and regulated by the Financial Conduct Authority FCA 315285.</div>
        <div><strong>Non-Disclosure of a Medical Condition</strong><br>The information provided by you in your proposal form has been used for the assessment and acceptance of you in this insurance. Your failure to provide correct information when applying for this insurance or when making any changes to it may render your policy void.</div>
        <hr>
        <div class="suson-footer">EduHealth, Sadler’s House, 4-6 South Parade, Bawtry, South Yorkshire DN10 6JH.<br>Telephone: 0345 226 9938</div>
EOD;

// print a block of text using Write()
$pdf->writeHTMLCell(0, 0, '', '', $txt, 0, 1, 0, true, '', true);
// ---------------------------------------------------------
// Mail pdf generated
$to = 'prazeev@gmail.com';
$subject = 'Receipt';
$repEmail = 'info@gmail.com';
$fileName = 'policy-schedule.pdf';

$file_to_attach = $pdf->Output($fileName, 'E');
$attachment = chunk_split($file_to_attach);
$eol = PHP_EOL;
$separator = md5(time());

$headers = 'From: Sender <' . $repEmail . '>' . $eol;
$headers .= 'MIME-Version: 1.0' . $eol;
$headers .= "Content-Type: multipart/mixed; boundary=\"" . $separator . "\"";

$message = "--" . $separator . $eol;
$message .= "Content-Transfer-Encoding: 7bit" . $eol . $eol;
$message .= "This is a MIME encoded message." . $eol;

$message .= "--" . $separator . $eol;
$message .= "Content-Type: text/html; charset=\"iso-8859-1\"" . $eol;
$message .= "Content-Transfer-Encoding: 8bit" . $eol . $eol;

$message .= "--" . $separator . $eol;
$message .= "Content-Type: application/pdf; name=\"" . $fileName . "\"" . $eol;
$message .= "Content-Transfer-Encoding: base64" . $eol;
$message .= "Content-Disposition: attachment" . $eol . $eol;
$message .= $attachment . $eol;
$message .= "--" . $separator . "--";

@mail($to, $subject, $message, $headers);

// Show pdf generated

function send_csv_mail($body = '', $to = 'prazeev@gmail.com', $subject = 'Website Report CSV', $from = 'noreply@teamsixofive.com') {

    // This will provide plenty adequate entropy
    $multipartSep = '-----' . md5(time()) . '-----';

    // Arrays are much more readable
    $headers = array(
        "From: $from",
        "Reply-To: $from",
        "Content-Type: multipart/mixed; boundary=\"$multipartSep\""
    );

    // Make the attachment
    $attachment = chunk_split(base64_encode(create_csv_string()));

    // Make the body of the message
    $body = "--$multipartSep\r\n"
            . "Content-Type: text/plain; charset=ISO-8859-1; format=flowed\r\n"
            . "Content-Transfer-Encoding: 7bit\r\n"
            . "\r\n"
            . "$body\r\n"
            . "--$multipartSep\r\n"
            . "Content-Type: text/csv\r\n"
            . "Content-Transfer-Encoding: base64\r\n"
            . "Content-Disposition: attachment; filename=\"Website-Report-" . date("F-j-Y") . ".csv\"\r\n"
            . "\r\n"
            . "$attachment\r\n"
            . "--$multipartSep--";

    // Send the email, return the result
    return @mail($to, $subject, $body, implode("\r\n", $headers));
}

//$array = array(array(1,2,3,4,5,6,7), array(1,2,3,4,5,6,7), array(1,2,3,4,5,6,7));
//send_csv_mail($array, "Website Report \r\n \r\n www.carlofontanos.com");
function create_csv_string() {
    $data = array();
    $data['title'] = $_POST['data-title'];
    $data['fname'] = $_POST['data-fname'];
    $data['lname'] = $_POST['data-lname'];
    $data['dob'] = $_POST['data-dob-dd'] . "-" . $_POST['data-dob-mm'] . "-" . $_POST['data-dob'];
    $data['gender'] = $_POST['data-gender'];
    $data['telephone'] = $_POST['data-telephone'];
    $data['email'] = $_POST['data-email'];
    $data['postcode'] = $_POST['data-postcode'];
    $data['address'] = $_POST['data-address'];
    $data['sdate'] = $_POST['data-sdate'];

    if (isset($_POST['data-titlef'])) {
        $family = array();
        $family['title'] = $_POST['data-titlef'];
        $family['fname'] = $_POST['data-fnamef'];
        $family['lname'] = $_POST['data-lnamef'];
        $family['dobdd'] = $_POST['data-dob-ddf'];
        $family['dobmm'] = $_POST['data-dob-mmf'];
        $family['dobyy'] = $_POST['data-dobf'];
        $family['relation'] = $_POST['data-relationf'];
        $family['gender'] = $_POST['data-genderf'];
    } else {
        $no_family = 1;
        $family = array();
        $family['title'] = '';
        $family['fname'] = '';
        $family['lname'] = '';
        $family['dobdd'] = '';
        $family['dobmm'] = '';
        $family['dobyy'] = '';
        $family['relation'] = '';
        $family['gender'] = '';
    }

    $plan['excesstype'] = $_POST['data-excesstype'];
    $plan['whichplan'] = $_POST['whichplan'];
    $plan['monthly'] = $_POST['monthly'];
    $plan['annual'] = $_POST['annual'];
    $plan['paytype'] = $_POST['paytype'];

    $others['data-resident'] = (isset($_POST['data-resident']) ? "Yes" : "No");
    $others['data-mailing'] = (isset($_POST['data-mailing']) ? "Yes" : "No");

    /*
      //$one['name'] = $_POST['data-name'];
      $one['height'] = $_POST['data-height'];
      //$one['relation'] = $_POST['data-relation'];
      $one['weight'] = $_POST['data-weight'];
      $one['smoke'] = $_POST['data-smoke'];
      $one['glass'] = $_POST['data-glass'];

      $two['des'] = $_POST['data-des'];

      $three['exact'] = $_POST['data-exact'];
      $three['symptoms'] = $_POST['data-symptoms'];
      $three['treatment'] = $_POST['data-treatment'];
      $three['recovery'] = $_POST['data-recovery'];
      $three['otreatment'] = $_POST['data-otreatment'];

     */
    $holderone = $_POST['account-holder1'];
    $holdertwo = $_POST['account-holder2'];
    $societyno = $_POST['one1'] . $_POST['one2'] . $_POST['one3'] . $_POST['one4'] . $_POST['one5'] . $_POST['one6'] . $_POST['one7'] . $_POST['one8'];
    $branch = $_POST['two1'] . $_POST['two2'] . $_POST['two3'] . $_POST['two4'] . $_POST['two5'] . $_POST['two6'];



    if (!$fp = fopen('php://temp', 'w+'))
        return FALSE;

    fputcsv($fp, array("User Details"));
    fputcsv($fp, array("Title", "FirstName", "Surname", "Date of Birth", "Gender", "Telephone", "Email", "Postcode", "Address", "Start Date"));
    fputcsv($fp, $data);
    fputcsv($fp, array("Family to be Covered"));
    fputcsv($fp, array("Title", "FirstName", "Surname", "Date Day", "Date Month", "Date Year", "Relation", "Gender"));
    $fam = array();
    if (!isset($no_family)) {
        foreach ($family as $key => $value) {
            foreach ($value as $v => $k) {
                $fam[$v][$key] = $family[$key][$v];
            }
        }
    }
    foreach ($fam as $key => $value) {
        fputcsv($fp, $value);
    }
    fputcsv($fp, array("Selected plan details"));
    fputcsv($fp, array("Excesstype", "Whichplan", "Monthly", "Annual", "Costumer Pay Type"));
    fputcsv($fp, $plan);


    fputcsv($fp, array("Additional Details"));
    fputcsv($fp, array("Tick box to con?rm that you are resident in the UK and are registered with a UK General Practitioner", "Tick box to con?rm you wish to opt out of mailings etc"));
    fputcsv($fp, $others);
//For Lifestyle first two
    /*
      $fa = array();
      $one['name']  = array($data['fname']." ".$data['lname']);
      foreach ($family['fname'] as $key => $value) {
      array_push($one['name'],$value);
      }
      $one['relation'] = array("Self");
      foreach ($family['relation'] as $key => $value) {
      array_push($one['relation'],$value);
      }
      foreach ($one as $key => $value) {
      foreach ($value as $v => $k) {
      $fa[$v][$key] = $one[$key][$v];
      }
      }
      while (sizeof($fa) != sizeof($fam)+1) {
      array_pop($fa);
      }
      fputcsv($fp, array("Lifestyle First Part"));
      foreach ($fa as $key => $value) {
      fputcsv($fp, array("Height","Weight","Smoke","Glass","Name","Relation"));
      fputcsv($fp, $value);
      }


      //For Rest of lifestyle
      $fa = array();
      $two['name']  = array($data['fname']." ".$data['lname']);
      foreach ($family['fname'] as $key => $value) {
      array_push($two['name'],$value);
      }
      $two['relation'] = array("Self");
      foreach ($family['relation'] as $key => $value) {
      array_push($two['relation'],$value);
      }
      foreach ($two as $key => $value) {
      foreach ($value as $v => $k) {
      $fa[$v][$key] = $two[$key][$v];
      }
      }
      while (sizeof($fa) != sizeof($fam)+1) {
      array_pop($fa);
      }
      fputcsv($fp, array("Lifestyle Second Part"));
      foreach ($fa as $key => $value) {
      fputcsv($fp, array("Description","Name","Relation"));
      fputcsv($fp, $value);
      }

      //For Third part
      $fa = array();
      $three['name']  = array($data['fname']." ".$data['lname']);
      foreach ($family['fname'] as $key => $value) {
      array_push($three['name'],$value);
      }
      foreach ($three as $key => $value) {
      foreach ($value as $v => $k) {
      $fa[$v][$key] = $three[$key][$v];
      }
      }
      while (sizeof($fa) != sizeof($fam)+1) {
      array_pop($fa);
      }
      fputcsv($fp, array("Medical Questions"));
      foreach ($fa as $key => $value) {
      fputcsv($fp, array("Exact","Symptoms","Treatment","Recovery","Other Treatment","Name"));
      fputcsv($fp, $value);
      }
     */
    //Account Holder Details
    fputcsv($fp, array("Account Details"));
    fputcsv($fp, array("Account Holder 1", $holderone));
    fputcsv($fp, array("Account Holder 2", $holdertwo));
    fputcsv($fp, array("Society Number", $societyno));
    fputcsv($fp, array("Branch Number", $branch));

    // Loop data and write to file pointer
    //$line = array("Hello","Hy","how");
    // Place stream pointer at beginning
    rewind($fp);

    // Return the data
    return stream_get_contents($fp);
}

send_csv_mail();



$pdf->Output('policy-schedule.pdf', 'I');
?>