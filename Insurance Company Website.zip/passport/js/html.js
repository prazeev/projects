$(function () {
    $('.date').datepicker({
        format: 'dd/mm/yyyy',
        startDate: '0d',
        autoclose: true
    });


    function datec(date) {
        var datearray = date.split("/");

        var newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
        return newdate;
    }
    var title;
    var fname;
    var lname;
    var dob;
    var check = 0;
    var a;
    var b;
    var c;
    var d;
    var age;
    var agei;
    var gender;
    var occupation;
    var telephone;
    var email;
    var postcode;
    var address;
    var sdate;
    var excesstype;
    var passport = [];
    var passportarray = [];
    var passportplusarray = [];
    var passportplus;
    var titlef = [];
    var fnamef = [];
    var lnamef = [];
    var dobf = [];
    var dobddf = [];
    var dobmmf = [];
    var relationf = [];
    var genderf = [];
    var option;
    $(document).on("click", ".two-yes,.height-weight,.one-four-five", function (e) {
        e.preventDefault();
        $($(this).parent()).siblings(":last").children().slideDown();
        if ($(this).siblings(":last").hasClass("comp")) {
            if ($(this).siblings(":last").hasClass("red"))
                check--;
        }
        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
        } else {
            $(this).addClass("red");
        }
        $(this).siblings(":last").removeClass("red");
    });
    var sayc = 0;
    $(document).on("keyup", '[name^="data-exact"],[name^="data-symptoms"],[name^="data-treatment"],[name^="data-otreatment"],[name^="data-relation"],[name^="data-recovery"],[name^="data-des"],[name^="data-name"],[name^="data-relation"],[name^="data-height"],[name^="data-weight"],[name^="data-smoke"],[name^="data-glass"]', function () {
        var name = $(this).attr('name').split("[]");
        var d = $(this).attr(name[0]);
        $("[" + name[0] + "^=" + d + "]").val($(this).val());
        //alert(d);
    });
    function data() {
        title = $("[name=data-title]").val();
        fname = $("[name=data-fname]").val();
        lname = $("[name=data-lname]").val();
        dob = $("[name=data-dob-dd]").val() + "/" + $("[name=data-dob-mm]").val() + "/" + $("[name=data-dob]").val();
        gender = $("[name=data-gender]").val();
        occupation = $("[name=data-occupation]").val();
        telephone = $("[name=data-telephone]").val();
        email = $("[name=data-email]").val();
        postcode = $("[name=data-postcode]").val();
        address = $("[name=data-address]").val();
        sdate = datec($("[name=data-sdate]").val());
        excesstype = $("[name=data-excesstype]").val();
        c = new Date(sdate);
        a = new Date(dob);
        d = new Date();
        age = d.getFullYear() - a.getFullYear();
        passportarray = [["17", "22.35", "254.79"],
            ["18", "23.19", "264.40"], ["19", "24.36", "277.72"],
            ["20", "25.57", "291.55"], ["21", "26.83", "305.87"],
            ["22", "28.13", "320.69"], ["23", "29.49", "336.20"],
            ["24", "30.89", "352.20"], ["25", "32.33", "368.54"],
            ["26", "33.73", "384.55"], ["27", "34.34", "391.47"],
            ["28", "34.86", "397.37"], ["29", "36.13", "411.86"],
            ["30", "37.34", "425.68"], ["31", "38.37", "437.47"],
            ["32", "39.32", "448.27"], ["33", "40.31", "459.54"],
            ["34", "41.39", "471.85"], ["35", "42.50", "484.50"],
            ["36", "43.67", "497.80"], ["37", "44.82", "510.95"],
            ["38", "46.03", "524.76"], ["39", "47.27", "538.92"],
            ["40", "48.58", "553.76"], ["41", "49.99", "569.93"],
            ["42", "51.52", "587.29"], ["43", "53.10", "605.31"],
            ["44", "54.77", "624.38"], ["45", "56.40", "642.91"],
            ["46", "58.14", "662.78"], ["47", "59.84", "682.17"],
            ["48", "61.67", "703.05"], ["49", "63.61", "725.14"],
            ["50", "65.52", "746.87"], ["51", "67.81", "773.00"],
            ["52", "70.16", "799.79"], ["53", "72.67", "828.44"],
            ["54", "75.20", "857.25"], ["55", "77.84", "887.42"],
            ["56", "80.58", "918.59"], ["57", "83.37", "950.45"],
            ["58", "86.24", "983.14"], ["59", "89.27", "1,017.68"],
            ["60", "92.36", "1,052.92"], ["61", "96.56", "1100.76"],
            ["62", "100.87", "1149.97"],
            ["63", "105.47", "1202.39"], ["64", "110.25", "1256.82"],
            ["65", "115.29", "1314.28"], ["66", "120.54", "1374.11"],
            ["67", "126.11", "1437.64"], ["68", "131.93", "1504.05"],
            ["69", "137.92", "1572.29"], ["70", "144.23", "1644.25"],
            ["71", "150.75", "1718.56"], ["72", "157.57", "1796.26"],
            ["73", "164.72", "1877.82"], ["74", "172.13", "1962.24"],
            ["75", "179.98", "2051.74"], ["76", "188.18", "2145.27"],
            ["77", "196.80", "2243.51"], ["78", "207.32", "2363.50"],
            ["79", "218.09", "2486.17"], ["80", "224.37", "2557.80"]];
        passportplusarray = [["17", "20.12", "229.35"],
            ["18", "20.71", "236.09"], ["19", "21.77", "248.22"],
            ["20", "22.90", "261.04"],
            ["21", "24.07", "274.35"], ["22", "25.25", "287.83"],
            ["23", "26.49", "301.98"], ["24", "27.81", "316.98"],
            ["25", "29.09", "331.64"], ["26", "30.36", "346.13"],
            ["27", "30.49", "352.71"], ["28", "31.38", "357.76"],
            ["29", "32.51", "370.56"], ["30", "33.62", "383.21"],
            ["31", "34.52", "393.50"], ["32", "35.36", "403.08"],
            ["33", "36.31", "413.88"], ["34", "37.25", "424.67"],
            ["35", "38.27", "436.29"], ["36", "39.29", "447.93"],
            ["37", "40.33", "459.72"], ["38", "41.39", "471.85"],
            ["39", "42.50", "484.50"], ["40", "43.67", "497.80"],
            ["41", "44.97", "512.62"], ["42", "46.34", "528.31"],
            ["43", "47.76", "544.48"], ["44", "49.28", "561.84"],
            ["45", "50.78", "578.87"], ["46", "52.30", "596.23"],
            ["47", "53.88", "614.26"], ["48", "55.49", "632.62"],
            ["49", "57.22", "625.33"], ["50", "59.00", "672.56"],
            ["51", "61.05", "695.99"], ["52", "63.15", "719.91"],
            ["53", "65.40", "745.52"], ["54", "67.67", "771.48"],
            ["55", "70.08", "798.94"], ["56", "72.48", "826.25"],
            ["57", "75.02", "855.24"], ["58", "77.62", "884.90"],
            ["59", "80.36", "816.07"], ["60", "83.12", "947.59"],
            ["61", "86.91", "990.72"], ["62", "90.84", "1035.56"],
            ["63", "94.95", "1082.40"], ["64", "99.25", "1131.44"],
            ["65", "103.76", "1182.84"], ["66", "108.47", "1236.60"],
            ["67", "113.50", "1293.89"], ["68", "118.73", "1353.55"],
            ["69", "124.17", "1415.57"], ["70", "129.85", "1480.28"],
            ["71", "135.66", "1546.51"], ["72", "141.84", "1616.95"],
            ["73", "148.25", "1690.08"], ["74", "154.91", "1765.92"],
            ["75", "161.97", "1846.46"], ["76", "169.35", "1930.57"],
            ["77", "117.09", "2018.87"], ["78", "186.60", "2127.24"],
            ["79", "196.24", "2237.11"], ["80", "201.94", "2302.16"]];
    }
    $(document).on("click", "#b1", function () {
        $("#3b").hide();
        $("#3a").show();
        option = 1;
    });
    $(document).on("click", "#b2", function () {
        $("#3a").hide();
        $("#3b").show();
        option = 2;
    });
    $(document).on("click", ".select-no", function (e) {
        e.preventDefault();
        //alert("You cannot select no");

        $(this).siblings().removeClass("red");
        $($(this).parent()).siblings(":last").children().slideUp();
        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
            if ($(this).hasClass("comp")) {
                check--;
            }
        } else {
            $(this).addClass("red");
            if ($(this).hasClass("comp")) {
                check++;
            }
        }
        //alert(check);
    });

    $(document).on("click", "#button-to-last", function () {

        option = 1;
        if (excesstype === 'NIL') {
            $(".passport-m").html(passport[1]);
            $(".passport-y").html(passport[2]);
            $("[name=whichplan]").val("Passport");
            $("[name=monthly]").val(passport[1]);
            $("[name=annual]").val(passport[2]);
        } else if (excesstype === '£100') {
            $(".passport-m").html(passportplus[1]);
            $(".passport-y").html(passportplus[2]);
            $("[name=whichplan]").val("Passport");
            $("[name=monthly]").val(passportplus[1]);
            $("[name=annual]").val(passportplus[2]);
        }
        $(".first").show();
        $(".second,.three").hide();
    });
    $(document).on("click", "#pay-monthly", function () {
        $(".first").hide();
        $("[name=paytype]").val("Monthly");
        if (excesstype === 'NIL') {
            $(".paywhat").html("<b>Monthly</b>");
            $(".pay-bill").html(passport[1]);
        } else if (excesstype === '£100') {
            $(".paywhat").html("<b>Monthly</b>");
            $(".pay-bill").html(passportplus[1]);
        }
        $(".second").show();
    });

    $(document).on("click", "#pay-annual", function () {
        $(".first").hide();
        $("[name=paytype]").val("Annual");
        if (excesstype === 'NIL') {
            $(".paywhat").html("<b>Annual</b>");
            $(".pay-bill").html(passport[2]);
        } else if (excesstype === '£100') {
            $(".paywhat").html("<b>Annual</b>");
            $(".pay-bill").html(passportplus[2]);
        }
        $(".second").show();
    });
    ///var sayc = 0;
    var yes_one = 0;
    var yes_two = 0;
    $(document).on("click", ".yes-one", function () {
        yes_one = 1;
    });
    $(document).on("click", ".no-one", function () {
        yes_one = 0;
    });
    $(document).on("click", ".yes-two", function () {
        yes_two = 1;
    });
    $(document).on("click", ".no-two", function () {
        yes_two = 0;
    });
    $(document).on("click", ".say-yes", function (e) {
        e.preventDefault();

        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
            sayc--;
        } else {
            $(this).addClass("red");
            sayc++;
        }
        $(this).siblings().removeClass("red");
        if (Number(yes_one) + Number(yes_two) == 2) {
            $(".two").hide();
            $(".three").show();
        }
    });

    $(document).on("click", ".say-no", function (e) {
        e.preventDefault();
        if (Number(yes_one) + Number(yes_two) != 2) {

            $(".two").show();
            $(".three").hide();
        }
        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
            sayc++;
        } else {
            $(this).addClass("red");
            sayc--;
        }
        $(this).siblings().removeClass("red");
        alert("You must be the policyholder and/ or authorised signatory and/or the sole signatory of this account to progress with this application");
    });
    Array.prototype.SumArray = function (arr) {
        var sum = [];
        if (arr != null && this.length == arr.length) {
            for (var i = 0; i < arr.length; i++) {
                sum.push(+this[i] + +arr[i]);
            }
        }
        return sum;
    }
    $(document).on("change", "[name=excess-type]", function () {
        var value = $(this).val();
        $("[name=data-excesstype]").val(value);
        $("#button-to-2nd-last").removeAttr("disabled");
        $("[name=excess-type]").parent().children(".radio-checkbox").children("i").hide();
        $(this).parent().children(".radio-checkbox").children("i").show();
    });
    $(document).on("change", "[name=data-resident]", function () {
        if ($(this).is(":checked"))
            $("#button-to-last").removeAttr("disabled");
        else {
            $("#button-to-last").attr("disabled", "");
            alert("You must confirm your acceptance of the Declaration before proceeding");
        }
    });
    $(document).on("click", "#button-to-2nd-last-outer", function () {
        if ($(this).children("#button-to-2nd-last").is(":disabled")) {
            alert("You select excess first before proceeding");
        }
    });
    $(document).on("click", "#button-to-last-outer", function () {
        if ($(this).children("#button-to-last").is(":disabled")) {
            alert("You must confirm your acceptance of the Declaration before proceeding");
        }
    });
    $(document).on("click", ".stepone", function () {
        data();
        if (age < 17)
            agei = 17;
        else
            agei = age;
        for (var i = 0, len = passportarray.length; i < len; i++) {
            if (passportarray[i][0] == agei) {
                passport = passportarray[i];
                passportplus = passportplusarray[i];
                break;
            }
        }

        $(".title").html(title);
        $(".fname").html(fname);
        $(".lname").html(lname);
        $(".dob").html(dob);
        $(".gender").html(gender);
        $(".occupation").html(occupation);
        $(".address").html(address);
        $(".postcode").html(postcode);
        $(".telephone").html(telephone);
        $(".email").html(email);
        $(".sdate").html(datec(sdate));
        $(".excesstype").html(excesstype);
        a = new Date();
        b = new Date(sdate);
        if ((a.getTime() - b.getTime()) < 0) {
            titlef = [];
            fnamef = [];
            lnamef = [];
            dobf = [];
            relationf = [];
            genderf = [];
            dobmmf = [];
            dobddf = [];
            $('[name^="data-titlef"]').each(function () {
                titlef.push($(this).val());
            });
            $('[name^="data-fnamef"]').each(function () {
                fnamef.push($(this).val());
            });
            $('[name^="data-lnamef"]').each(function () {
                lnamef.push($(this).val());
            });
            $('[name^="data-dob-mmf"]').each(function () {
                dobmmf.push($(this).val());
            });
            $('[name^="data-dob-ddf"]').each(function () {
                dobddf.push($(this).val());
            });
            $('[name^="data-dobf"]').each(function () {
                dobf.push($(this).val());
                a = new Date();
                var agefa = 0;
                agefa = a.getFullYear() - $(this).val();
                if (agefa < 17)
                    ageii = 17;
                else
                    ageii = agefa;
                for (var i = 0, len = passportarray.length; i < len; i++) {
                    if (passportarray[i][0] == ageii) {
                        passport = passport.SumArray(passportarray[i]);
                        passportplus = passportplus.SumArray(passportplusarray[i]);
                        break;
                    }
                }
                passport[0] = passport[0] - ageii;
                passportplus[0] = passportplus[0] - ageii;
            });
            $('[name^="data-relationf"]').each(function () {
                relationf.push($(this).val());
            });
            $('[name^="data-genderf"]').each(function () {
                genderf.push($(this).val());
            });
            var member_list = " ";
            for (i = 0; i < titlef.length; i++) {
                member_list += "<tr>\
				<td>" + titlef[i] + "</td>\
				<td>" + fnamef[i] + "</td>\
				<td>" + lnamef[i] + "</td>\
				<td>" + dobddf[i] + "/" + dobmmf[i] + "/" + dobf[i] + "</td>\
				<td>" + relationf[i] + "</td>\
				<td>" + genderf[i] + "</td>\
			</tr>";
            }
            $(".family-members").html(member_list);
            //alert((240).toFixed(2))

            //alert(passport.toFixed(2));
            $(".passport-data-month").html(parseFloat(passport[1]).toFixed(2));
            $(".passport-data-month-first").html(parseFloat(passport[1]).toFixed(2));
            //alert(passport[1]);
            $(".passport-data-year").html(parseFloat(passport[2]).toFixed(2));

            //alert(passportplus.toFixed(2));
            $(".passportplus-data-month").html(parseFloat(passportplus[1]).toFixed(2));
            $(".passportplus-data-month-first").html(parseFloat(passportplus[1]).toFixed(2));
            //alert(passportplus[1]);
            $(".passportplus-data-year").html(parseFloat(passportplus[2]).toFixed(2));

            if (excesstype === 'NIL') {
                //alert(passport.toFixed(2));
                $(".excess-data-month").html(parseFloat(passport[1]).toFixed(2));
                $(".excess-data-month-first").html(parseFloat(passport[1]).toFixed(2));
                //alert(passport[1]);
                $(".excess-data-year").html(parseFloat(passport[2]).toFixed(2));
            } else if (excesstype === '£100') {
                //alert(passportplus.toFixed(2));
                $(".excess-data-month").html(parseFloat(passportplus[1]).toFixed(2));
                $(".excess-data-month-first").html(parseFloat(passportplus[1]).toFixed(2));
                //alert(passportplus[1]);
                $(".excess-data-year").html(parseFloat(passportplus[2]).toFixed(2));
            }
        }
    });

    $("#b2").click(function () {
        var append = '<hr>\
                                                	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2">Name</div>\
                                                			<div class="col-md-2">Relationship to policyholder</div>\
                                                			<div class="col-md-2">Height</div>\
                                                			<div class="col-md-2">Weight</div>\
                                                			<div class="col-md-2">If smoker. No. per day?</div>\
                                                			<div class="col-md-2">Alcohol No. of  glasses per week:  beer/wine/spirits per week</div>\
                                                		</div>\
                                                	</li>\
                                                	';

        var append1 = '<hr> \
                                                	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2">Name</div>\
                                                			<div class="col-md-2">Relationship to policyholder</div>\
                                                			<div class="col-md-8">If YES to questions 1.4 and/or 1.5 then please answer below</div>\
                                                		</div>\
                                                	</li>';
        append += '<li> \
            <div class="row">\
                <div class="col-md-2"><input type="text" class="form-control" disabled name="data-name[]" value="' + fname + ' ' + lname + '"></div>\
                <div class="col-md-2"><input name="data-relation[]" data-relation="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-height[]" data-height="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-weight[]" data-weight="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-smoke[]" data-smoke="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input type="text" data-glass="-1" name="data-glass[]" class="form-control"></div>\
            </div>\
        </li>';
        append1 += '   	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input type="text" name="data-name[]" disabled value="' + fname + ' ' + lname + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-relation[]" data-height="-1" type="text" disabled class="form-control"></div>\
                                                			<div class="col-md-8"><textarea name="data-des[]" data-des="-1" class="form-control"></textarea></div>\
                                                		</div>\
                                                	</li>';
        var append2 = '<hr>\
                                                	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2">Name</div>\
                                                			<div class="col-md-2">Exact diagnosis (describe the health condition and tests if no diagnosis</div>\
                                                			<div class="col-md-2">When did symptoms start and ﬁnish?</div>\
                                                			<div class="col-md-2">Treatment (medication, surgery, hospitalisation…)</div>\
                                                			<div class="col-md-2">Has there been a complete recovery?</div>\
                                                			<div class="col-md-2">Ongoing treatment</div> \
                                                		</div>\
                                                	</li>';
        append2 += '<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input name="data-name[]" type="text" disabled value="' + fname + ' ' + lname + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-exact[]" data-exact="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-symptoms[]" data-symptoms="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-treatment[]" data-treatment="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-recovery[]" data-recovery="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-otreatment[]" data-otreatment="-1" type="text" class="form-control"></div>\
                                                		</div>\
                                                	</li>';
        for (i = 0; i < titlef.length; i++) {
            append += '<li> \
            <div class="row">\
                <div class="col-md-2"><input type="text" class="form-control" disabled name="data-name[]" value="' + fnamef[i] + ' ' + lnamef[i] + '"></div>\
                <div class="col-md-2"><input name="data-relation[]" data-relation="' + i + '" type="text" disabled class="form-control" value="' + relationf[i] + '"></div>\
                <div class="col-md-2"><input name="data-height[]" data-height="' + i + '" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-weight[]" data-weight="' + i + '" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-smoke[]" data-smoke="' + i + '" type="text" class="form-control"></div>\
                <div class="col-md-2"><input type="text" data-glass="' + i + '" name="data-glass[]" class="form-control"></div>\
            </div>\
        </li>';

            append1 += '                                    	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input type="text" name="data-name[]" disabled value="' + fnamef[i] + ' ' + lnamef[i] + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input type="text" data-relation="' + i + '" name="data-relation[]" disabled value="' + relationf[i] + '" class="form-control"></div>\
                                                			<div class="col-md-8"><textarea name="data-des[]" data-des="' + i + '" class="form-control"></textarea></div>\
                                                		</div>\
                                                	</li>';
            append2 += '<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input name="data-name[]" type="text" disabled value="' + fnamef[i] + ' ' + lnamef[i] + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-exact[]" data-exact="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-symptoms[]" data-symptoms="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-treatment[]" data-treatment="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-recovery[]" data-recovery="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-otreatment[]" data-otreatment="' + i + '" type="text" class="form-control"></div>\
                                                		</div>\
                                                	</li>';

        }
        append += "<hr>";
        append1 += "<hr>";
        append2 += "<hr>";
        $(".height-weight-table").html(append);
        $(".one-four-five-table").html(append1);
        $(".two-one-to-6-table").html(append2);
    });
});