/*
	Author: Suson Waiba
	Email: susonwaiba@gmail.com
	Copyright: TeamSixoFive
	URL: http://teamsixofive.com
*/

$(function () {

    

    $('.date').datepicker({
        format: 'dd/mm/yyyy',
        startDate: '0d',
        autoclose: true
    });


    function datec(date) {
        var datearray = date.split("/");

        var newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
        return newdate;
    }
    var title;
    var fname;
    var lname;
    var dob;
    var check = 0;
    var a;
    var b;
    var c;
    var d;
    var age;
    var agei;
    var gender;
    var occupation;
    var telephone;
    var email;
    var postcode;
    var address;
    var sdate;
    var paymenttype;
    var passport = [];
    var passportarray = [];
    var titlef = [];
    var fnamef = [];
    var lnamef = [];
    var dobf = [];
    var dobddf = [];
    var dobmmf = [];
    var relationf = [];
    var genderf = [];
    var option;
    $(document).on("click", ".two-yes,.height-weight,.one-four-five", function (e) {
        e.preventDefault();
        $($(this).parent()).siblings(":last").children().slideDown();
        if ($(this).siblings(":last").hasClass("comp")) {
            if ($(this).siblings(":last").hasClass("red"))
                check--;
        }
        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
        } else {
            $(this).addClass("red");
        }
        $(this).siblings(":last").removeClass("red");
    });
    var sayc = 0;
    $(document).on("keyup", '[name^="data-exact"],[name^="data-symptoms"],[name^="data-treatment"],[name^="data-otreatment"],[name^="data-relation"],[name^="data-recovery"],[name^="data-des"],[name^="data-name"],[name^="data-relation"],[name^="data-height"],[name^="data-weight"],[name^="data-smoke"],[name^="data-glass"]', function () {
        var name = $(this).attr('name').split("[]");
        var d = $(this).attr(name[0]);
        $("[" + name[0] + "^=" + d + "]").val($(this).val());
        //alert(d);
    });
    function data() {
        title = $("[name=data-title]").val();
        fname = $("[name=data-fname]").val();
        lname = $("[name=data-lname]").val();
        dob = $("[name=data-dob-dd]").val() + "/" + $("[name=data-dob-mm]").val() + "/" + $("[name=data-dob]").val();
        gender = $("[name=data-gender]").val();
        occupation = $("[name=data-occupation]").val();
        telephone = $("[name=data-telephone]").val();
        email = $("[name=data-email]").val();
        postcode = $("[name=data-postcode]").val();
        address = $("[name=data-address]").val();
        sdate = datec($("[name=data-sdate]").val());
        paymenttype = $("[name=data-paymenttype]").val();
        c = new Date(sdate);
        a = new Date(dob);
        d = new Date();
        age = d.getFullYear() - a.getFullYear();
        passportarray = [["17", "12.50", "150.00"],
            ["18", "12.50", "150.00"], ["19", "25.00", "300.00"],
            ["20", "25.00", "300.00"], ["21", "25.00", "300.00"],
            ["22", "25.00", "300.00"], ["23", "25.00", "300.00"],
            ["24", "25.00", "300.00"], ["25", "25.00", "300.00"],
            ["26", "25.00", "300.00"], ["27", "25.00", "300.00"],
            ["28", "25.00", "300.00"], ["29", "25.00", "300.00"],
            ["30", "25.00", "300.00"], ["31", "25.00", "300.00"],
            ["32", "25.00", "300.00"], ["33", "25.00", "300.00"],
            ["34", "25.00", "300.00"], ["35", "25.00", "300.00"],
            ["36", "25.00", "300.00"], ["37", "25.00", "300.00"],
            ["38", "25.00", "300.00"], ["39", "25.00", "300.00"],
            ["40", "25.00", "300.00"], ["41", "25.00", "300.00"],
            ["42", "25.00", "300.00"], ["43", "25.00", "300.00"],
            ["44", "25.00", "300.00"], ["45", "25.00", "300.00"],
            ["46", "25.00", "300.00"], ["47", "25.00", "300.00"],
            ["48", "25.00", "300.00"], ["49", "25.00", "300.00"],
            ["50", "25.00", "300.00"], ["51", "25.00", "300.00"],
            ["52", "25.00", "300.00"], ["53", "25.00", "300.00"],
            ["54", "25.00", "300.00"], ["55", "25.00", "300.00"],
            ["56", "25.00", "300.00"], ["57", "25.00", "300.00"],
            ["58", "25.00", "300.00"], ["59", "25.00", "300.00"],
            ["60", "25.00", "300.00"], ["61", "25.00", "300.00"],
            ["62", "25.00", "300.00"],
            ["63", "25.00", "300.00"], ["64", "25.00", "300.00"],
            ["65", "33.34", "400.00"], ["66", "33.34", "400.00"],
            ["67", "33.34", "400.00"], ["68", "33.34", "400.00"],
            ["69", "33.34", "400.00"], ["70", "33.34", "400.00"],
            ["71", "33.34", "400.00"], ["72", "33.34", "400.00"],
            ["73", "33.34", "400.00"], ["74", "33.34", "400.00"],
            ["75", "33.34", "400.00"], ["76", "33.34", "400.00"],
            ["77", "33.34", "400.00"], ["78", "33.34", "400.00"],
            ["79", "33.34", "400.00"], ["80", "33.34", "400.00"]];
    }
    $(document).on("click", "#b1", function () {
        $("#3b").hide();
        $("#3a").show();
        option = 1;
    });
    $(document).on("click", "#b2", function () {
        $("#3a").hide();
        $("#3b").show();
        option = 2;
    });
    $(document).on("click", ".select-no", function (e) {
        e.preventDefault();
        //alert("You cannot select no");

        $(this).siblings().removeClass("red");
        $($(this).parent()).siblings(":last").children().slideUp();
        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
            if ($(this).hasClass("comp")) {
                check--;
            }
        } else {
            $(this).addClass("red");
            if ($(this).hasClass("comp")) {
                check++;
            }
        }
        //alert(check);
    });

    // Code of 2nd step goes here

    $(document).on("click", ".step-2-list .step-2-btn-11", function () {
        if(!$(this).hasClass('active')) {
            $(this).addClass('active');
            if(!$(this).hasClass('step-2-btn-clicked')) {
                $(this).addClass('step-2-btn-clicked');
            }
        } else {
            $(this).removeClass('active');
            if($(this).hasClass('step-2-btn-clicked')) {
                $(this).removeClass('step-2-btn-clicked');
            }
        }
        if($('.step-2-btn-clicked').length === 11) {
            $('#button-to-2nd-last').removeAttr('disabled');
        }
        return false;
    });
    $(document).on("click", ".step-2-list .step-2-btn-yes", function () {
        if(!$(this).hasClass('active')) {
            $(this).addClass('active');
            $(this).parent().parent().children().children('.step-2-btn-no').removeClass('active');
            if(!$(this).hasClass('step-2-btn-clicked')) {
                $(this).addClass('step-2-btn-clicked');
            }
            if($(this).parent().parent().children().children('.step-2-btn-no').hasClass('step-2-btn-clicked')) {
                $(this).parent().parent().children().children('.step-2-btn-no').removeClass('step-2-btn-clicked');
            }
        }
        if($('.step-2-btn-clicked').length === 11) {
            $('#button-to-2nd-last').removeAttr('disabled');
        }
        return false;
    });
    $(document).on("click", ".step-2-list .step-2-btn-no", function () {
        if(!$(this).hasClass('active')) {
            $(this).addClass('active');
            $(this).parent().parent().children().children('.step-2-btn-yes').removeClass('active');
            if(!$(this).hasClass('step-2-btn-clicked')) {
                $(this).addClass('step-2-btn-clicked');
            }
            if($(this).parent().parent().children().children('.step-2-btn-yes').hasClass('step-2-btn-clicked')) {
                $(this).parent().parent().children().children('.step-2-btn-yes').removeClass('step-2-btn-clicked');
            }
        }
        if($('.step-2-btn-clicked').length === 11) {
            $('#button-to-2nd-last').removeAttr('disabled');
        }
        return false;
    });
    $(document).on("click", ".step-2-list .step-2-2-btn-yes", function () {
        if(!$(this).hasClass('active')) {
            $(this).addClass('active');
            $(this).parent().parent().children().children('.step-2-2-btn-no').removeClass('active');
            if(!$(this).hasClass('step-2-btn-clicked')) {
                $(this).addClass('step-2-btn-clicked');
            }
            if($(this).parent().parent().children().children('.step-2-2-btn-no').hasClass('step-2-btn-clicked')) {
                $(this).parent().parent().children().children('.step-2-2-btn-no').removeClass('step-2-btn-clicked');
            }
        }
        if($('.step-2-btn-clicked').length === 11) {
            $('#button-to-2nd-last').removeAttr('disabled');
        }
        return false;
    });
    $(document).on("click", ".step-2-list .step-2-2-btn-no", function () {
        if(!$(this).hasClass('active')) {
            $(this).addClass('active');
            $(this).parent().parent().children().children('.step-2-2-btn-yes').removeClass('active');
            if(!$(this).hasClass('step-2-btn-clicked')) {
                $(this).addClass('step-2-btn-clicked');
            }
            if($(this).parent().parent().children().children('.step-2-2-btn-yes').hasClass('step-2-btn-clicked')) {
                $(this).parent().parent().children().children('.step-2-2-btn-yes').removeClass('step-2-btn-clicked');
            }
        }
        if($('.step-2-btn-clicked').length === 11) {
            $('#button-to-2nd-last').removeAttr('disabled');
        }
        return false;
    });

    $(document).on("click", "#button-to-second", function () {
        $(".first").show();
        $(".second").hide();
    });
    $(document).on("click", "#button-to-step2-second", function () {
        $(".first").hide();
        $(".second").show();
    });
    $(document).on("click", ".step-2-btn-yes", function() {
        var href = $(this).attr('href');
        $(href).collapse({ 'toggle': false }).collapse('show');
    });
    $(document).on("click", ".step-2-btn-no", function() {
        var href = $(this).attr('href');
        $(href).collapse({ 'toggle': false }).collapse('hide');
    });
    $(document).on("click", ".step-2-2-btn-yes", function() {
        alert('Unfortunately, we are not able to offer Critical Advantage benefits cover to any individual proposed for cover on this policy who have suffered with any of the conditions listed.');
    });
    $(document).on("click", "#button-to-last", function () {

        option = 1;
        $(".passport-m").html(passport[1]);
        $(".passport-y").html(passport[2]);
        $("[name=whichplan]").val("Passport");
        $("[name=monthly]").val(passport[1]);
        $("[name=annual]").val(passport[2]);
        $(".first").show();
        $(".second").hide();
    });
    $(document).on("click", "#pay-monthly", function () {
        $(".first").hide();
        $("[name=paytype]").val("Monthly");
        $(".paywhat").html("<b>Monthly</b>");
        $(".pay-bill").html(passport[1]);
        $(".second").show();
    });

    $(document).on("click", "#pay-annual", function () {
        $(".first").hide();
        $("[name=paytype]").val("Annual");
        $(".paywhat").html("<b>Annual</b>");
        $(".pay-bill").html(passport[2]);
        $(".second").show();
    });
    ///var sayc = 0;
    var yes_one = 0;
    var yes_two = 0;
    $(document).on("click", ".yes-one", function () {
        yes_one = 1;
    });
    $(document).on("click", ".no-one", function () {
        yes_one = 0;
    });
    $(document).on("click", ".yes-two", function () {
        yes_two = 1;
    });
    $(document).on("click", ".no-two", function () {
        yes_two = 0;
    });
    $(document).on("click", ".say-yes", function (e) {
        e.preventDefault();

        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
            sayc--;
        } else {
            $(this).addClass("red");
            sayc++;
        }
        $(this).siblings().removeClass("red");
        if (Number(yes_one) + Number(yes_two) == 2) {
            $(".first").hide();
            $(".second").show();
        }
    });

    $(document).on("click", ".say-no", function (e) {
        e.preventDefault();
        if (Number(yes_one) + Number(yes_two) != 2) {

            $(".first").show();
            $(".second").hide();
        }
        if ($(this).hasClass("red")) {
            $(this).removeClass("red");
            sayc++;
        } else {
            $(this).addClass("red");
            sayc--;
        }
        $(this).siblings().removeClass("red");
        alert("You must be the policyholder and/ or authorised signatory and/or the sole signatory of this account to progress with this application");
    });
    Array.prototype.SumArray = function (arr) {
        var sum = [];
        if (arr != null && this.length == arr.length) {
            for (var i = 0; i < arr.length; i++) {
                sum.push(+this[i] + +arr[i]);
            }
        }
        return sum;
    }
    $(document).on("change", "[name=payment-type]", function () {
        var value = $(this).val();
        $("[name=data-paymenttype]").val(value);
        $("#button-to-step2-second").removeAttr("disabled");
        $("[name=payment-type]").parent().children(".radio-checkbox").children("i").hide();
        $(this).parent().children(".radio-checkbox").children("i").show();
    });
    $(document).on("change", "[name=data-resident]", function () {
        if ($(this).is(":checked"))
            $("#button-to-last").removeAttr("disabled");
        else {
            $("#button-to-last").attr("disabled", "");
            alert("You must confirm your acceptance of the Declaration before proceeding");
        }
    });
    $(document).on("click", "#button-to-2nd-last-outer", function () {
        if ($(this).children("#button-to-2nd-last").is(":disabled")) {
            alert("You must provide above data before proceeding");
        }
    });
    $(document).on("click", "#button-to-last-outer", function () {
        if ($(this).children("#button-to-last").is(":disabled")) {
            alert("You must confirm your acceptance of the Declaration before proceeding");
        }
    });
    $(document).on("click", ".stepone", function () {

        var payment_data_monthly = 0;
        var payment_data_annually = 0;


        data();
        if (age < 17)
            agei = 17;
        else
            agei = age;
        for (var i = 0, len = passportarray.length; i < len; i++) {
            if (passportarray[i][0] == agei) {
                passport = passportarray[i];
                payment_data_monthly = payment_data_monthly + parseFloat(passportarray[i][1]);
                payment_data_annually = payment_data_annually + parseFloat(passportarray[i][2]);
                break;
            }
        }

        $(".title").html(title);
        $(".fname").html(fname);
        $(".lname").html(lname);
        $(".dob").html(dob);
        $(".gender").html(gender);
        $(".occupation").html(occupation);
        $(".address").html(address);
        $(".postcode").html(postcode);
        $(".telephone").html(telephone);
        $(".email").html(email);
        $(".sdate").html(datec(sdate));
        $(".paymenttype").html(paymenttype);
        a = new Date();
        b = new Date(sdate);
        if ((a.getTime() - b.getTime()) < 0) {
            titlef = [];
            fnamef = [];
            lnamef = [];
            dobf = [];
            relationf = [];
            genderf = [];
            dobmmf = [];
            dobddf = [];
            var fpassport = [];
            $('[name^="data-titlef"]').each(function () {
                titlef.push($(this).val());
            });
            $('[name^="data-fnamef"]').each(function () {
                fnamef.push($(this).val());
            });
            $('[name^="data-lnamef"]').each(function () {
                lnamef.push($(this).val());
            });
            $('[name^="data-dob-mmf"]').each(function () {
                dobmmf.push($(this).val());
            });
            $('[name^="data-dob-ddf"]').each(function () {
                dobddf.push($(this).val());
            });
            $('[name^="data-dobf"]').each(function () {
                dobf.push($(this).val());
                a = new Date();
                var agefa = 0;
                var ageii;
                agefa = a.getFullYear() - $(this).val();
                if (agefa < 17)
                    ageii = 17;
                else
                    ageii = agefa;

                for (var i = 0, len = passportarray.length; i < len; i++) {
                    if (passportarray[i][0] == ageii) {
                        fpassport.push(passportarray[i]);
                        payment_data_monthly = payment_data_monthly + parseFloat(passportarray[i][1]);
                        payment_data_annually = payment_data_annually + parseFloat(passportarray[i][2]);
                        break;
                    }
                }
            });

            $('[name^="data-relationf"]').each(function () {
                relationf.push($(this).val());
            });
            $('[name^="data-genderf"]').each(function () {
                genderf.push($(this).val());
            });
            var member_list1 = " ";
            for (i = 0; i < titlef.length; i++) {
                member_list1 += "<tr>\
				<td class=\"text-left odd-column\">" + titlef[i] + " " + fnamef[i] + " " + lnamef[i] + "</td>\
				<td class=\"text-center even-column\">" + dobddf[i] + "/" + dobmmf[i] + "/" + dobf[i] + "</td>\
				<td class=\"text-center odd-column\">&pound;" + fpassport[i][1] + "</td>\
				<td class=\"text-center even-column\">&pound;" + fpassport[i][2] + "</td>\
			</tr>";
            }
            member_list1 += "<tr>\
                <td class=\"text-left odd-column\">&nbsp;</td>\
                <td class=\"text-center even-column\">&nbsp;</td>\
                <td class=\"text-center odd-column\">&nbsp;</td>\
                <td class=\"text-center even-column\">&nbsp;</td>\
            </tr>";
            member_list1 += "<tr>\
                <td class=\"text-left odd-column\">&nbsp;</td>\
                <td class=\"text-center even-column\">&nbsp;</td>\
                <td class=\"text-center odd-column\">&nbsp;</td>\
                <td class=\"text-center even-column\">&nbsp;</td>\
            </tr>";
            $(".family-members1").html(member_list1);


            var member_list = " ";
            for (i = 0; i < titlef.length; i++) {
                member_list += "<tr>\
                <td>" + titlef[i] + "</td>\
                <td>" + fnamef[i] + "</td>\
                <td>" + lnamef[i] + "</td>\
                <td>" + dobddf[i] + "/" + dobmmf[i] + "/" + dobf[i] + "</td>\
                <td>" + relationf[i] + "</td>\
                <td>" + genderf[i] + "</td>\
            </tr>";
            }
            $(".family-members").html(member_list);
            
            // step 2 dropdowns
            var member_list_1_1 = " ";
            for (i = 0; i < titlef.length; i++) {
                member_list_1_1 += "<tr>\
                <td class=\"name\">" + titlef[i] + " " + fnamef[i] + " " + lnamef[i] + "</td>\
                <td class=\"relationship\">" + relationf[i] + "</td>\
                <td class=\"height\"><input name=\"family-1-1-height[" + i + "]\"></td>\
                <td class=\"weight\"><input name=\"family-1-1-wight[" + i + "]\"></td>\
            </tr>";
            }
            $(".family-members-1-1").html(member_list_1_1);
            var member_list_1_2 = " ";
            for (i = 0; i < titlef.length; i++) {
                member_list_1_2 += "<tr>\
                <td class=\"name\">" + titlef[i] + " " + fnamef[i] + " " + lnamef[i] + "</td>\
                <td class=\"relationship\">" + relationf[i] + "</td>\
                <td class=\"if-smoker\"><input name=\"family-1-2-if-smoker[" + i + "]\"></td>\
            </tr>";
            }
            $(".family-members-1-2").html(member_list_1_2);
            var member_list_1_3 = " ";
            for (i = 0; i < titlef.length; i++) {
                member_list_1_3 += "<tr>\
                <td class=\"name\">" + titlef[i] + " " + fnamef[i] + " " + lnamef[i] + "</td>\
                <td class=\"relationship\">" + relationf[i] + "</td>\
                <td class=\"alcohol\"><input name=\"family-1-3-alcohol[" + i + "]\"></td>\
            </tr>";
            }
            $(".family-members-1-3").html(member_list_1_3);
            var member_list_1_4 = " ";
            for (i = 0; i < titlef.length; i++) {
                member_list_1_4 += "<tr>\
                <td class=\"name\">" + titlef[i] + " " + fnamef[i] + " " + lnamef[i] + "</td>\
                <td class=\"relationship\">" + relationf[i] + "</td>\
                <td class=\"advice\"><input name=\"family-1-4-advice[" + i + "]\"></td>\
            </tr>";
            }
            $(".family-members-1-4").html(member_list_1_4);
            var member_list_1_5 = " ";
            for (i = 0; i < titlef.length; i++) {
                member_list_1_5 += "<tr>\
                <td class=\"name\">" + titlef[i] + " " + fnamef[i] + " " + lnamef[i] + "</td>\
                <td class=\"relationship\">" + relationf[i] + "</td>\
                <td class=\"sport\"><input name=\"family-1-5-sport[" + i + "]\"></td>\
            </tr>";
            }
            $(".family-members-1-5").html(member_list_1_5);
            //alert((240).toFixed(2))
            
            $(".payment-data-month").html(parseFloat(passport[1]).toFixed(2));
            $(".payment-data-year").html(parseFloat(passport[2]).toFixed(2));

            $('[name^="payment-data-monthly"]').val(payment_data_monthly.toFixed(2));
            $('[name^="payment-data-annually"]').val(payment_data_annually.toFixed(2));
            $(".payment-data-monthly").html(payment_data_monthly.toFixed(2));
            $(".payment-data-annually").html(payment_data_annually.toFixed(2));
            
            if(paymenttype === 'Monthly') {
                $(".total-premium").html(payment_data_monthly.toFixed(2));
            } else {
                $(".total-premium").html(payment_data_annually.toFixed(2));
            }
        }
    });

    $("#b2").click(function () {
        var append = '<hr>\
                                                	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2">Name</div>\
                                                			<div class="col-md-2">Relationship to policyholder</div>\
                                                			<div class="col-md-2">Height</div>\
                                                			<div class="col-md-2">Weight</div>\
                                                			<div class="col-md-2">If smoker. No. per day?</div>\
                                                			<div class="col-md-2">Alcohol No. of  glasses per week:  beer/wine/spirits per week</div>\
                                                		</div>\
                                                	</li>\
                                                	';

        var append1 = '<hr> \
                                                	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2">Name</div>\
                                                			<div class="col-md-2">Relationship to policyholder</div>\
                                                			<div class="col-md-8">If YES to questions 1.4 and/or 1.5 then please answer below</div>\
                                                		</div>\
                                                	</li>';
        append += '<li> \
            <div class="row">\
                <div class="col-md-2"><input type="text" class="form-control" disabled name="data-name[]" value="' + fname + ' ' + lname + '"></div>\
                <div class="col-md-2"><input name="data-relation[]" data-relation="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-height[]" data-height="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-weight[]" data-weight="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-smoke[]" data-smoke="-1" type="text" class="form-control"></div>\
                <div class="col-md-2"><input type="text" data-glass="-1" name="data-glass[]" class="form-control"></div>\
            </div>\
        </li>';
        append1 += '   	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input type="text" name="data-name[]" disabled value="' + fname + ' ' + lname + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-relation[]" data-height="-1" type="text" disabled class="form-control"></div>\
                                                			<div class="col-md-8"><textarea name="data-des[]" data-des="-1" class="form-control"></textarea></div>\
                                                		</div>\
                                                	</li>';
        var append2 = '<hr>\
                                                	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2">Name</div>\
                                                			<div class="col-md-2">Exact diagnosis (describe the health condition and tests if no diagnosis</div>\
                                                			<div class="col-md-2">When did symptoms start and ﬁnish?</div>\
                                                			<div class="col-md-2">Treatment (medication, surgery, hospitalisation…)</div>\
                                                			<div class="col-md-2">Has there been a complete recovery?</div>\
                                                			<div class="col-md-2">Ongoing treatment</div> \
                                                		</div>\
                                                	</li>';
        append2 += '<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input name="data-name[]" type="text" disabled value="' + fname + ' ' + lname + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-exact[]" data-exact="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-symptoms[]" data-symptoms="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-treatment[]" data-treatment="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-recovery[]" data-recovery="-1" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-otreatment[]" data-otreatment="-1" type="text" class="form-control"></div>\
                                                		</div>\
                                                	</li>';
        for (i = 0; i < titlef.length; i++) {
            append += '<li> \
            <div class="row">\
                <div class="col-md-2"><input type="text" class="form-control" disabled name="data-name[]" value="' + fnamef[i] + ' ' + lnamef[i] + '"></div>\
                <div class="col-md-2"><input name="data-relation[]" data-relation="' + i + '" type="text" disabled class="form-control" value="' + relationf[i] + '"></div>\
                <div class="col-md-2"><input name="data-height[]" data-height="' + i + '" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-weight[]" data-weight="' + i + '" type="text" class="form-control"></div>\
                <div class="col-md-2"><input name="data-smoke[]" data-smoke="' + i + '" type="text" class="form-control"></div>\
                <div class="col-md-2"><input type="text" data-glass="' + i + '" name="data-glass[]" class="form-control"></div>\
            </div>\
        </li>';

            append1 += '                                    	<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input type="text" name="data-name[]" disabled value="' + fnamef[i] + ' ' + lnamef[i] + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input type="text" data-relation="' + i + '" name="data-relation[]" disabled value="' + relationf[i] + '" class="form-control"></div>\
                                                			<div class="col-md-8"><textarea name="data-des[]" data-des="' + i + '" class="form-control"></textarea></div>\
                                                		</div>\
                                                	</li>';
            append2 += '<li>\
                                                		<div class="row">\
                                                			<div class="col-md-2"><input name="data-name[]" type="text" disabled value="' + fnamef[i] + ' ' + lnamef[i] + '" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-exact[]" data-exact="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-symptoms[]" data-symptoms="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-treatment[]" data-treatment="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-recovery[]" data-recovery="' + i + '" type="text" class="form-control"></div>\
                                                			<div class="col-md-2"><input name="data-otreatment[]" data-otreatment="' + i + '" type="text" class="form-control"></div>\
                                                		</div>\
                                                	</li>';

        }
        append += "<hr>";
        append1 += "<hr>";
        append2 += "<hr>";
        $(".height-weight-table").html(append);
        $(".one-four-five-table").html(append1);
        $(".two-one-to-6-table").html(append2);
    });
});