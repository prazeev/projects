<?php
$name = "V001-TEST READ ALL"; // Title of the post
$name = array_map('trim',explode("-", $name));
$files = array("V001-TEST READ ALL","V002-TEST READ ALL","V003 -TEST READ ALL","V004- TEST READ ALL","V005- TEST READ ALL","V006-TEST READ ALL - Some Extra Information","V007-TEST READ ALL - There will always be a - for extra info","V008-TEST READ ALL - This work is complex Bla bla ABAK (19283) ","V008-TERST READ ALL - This work is complex Bla bla ABAK (19283) ","V009-TEST READ ALL - Final Version"); //The files from dir in array 1D
    $data = array(); //empty array for matched files with $name
    $download = ""; //Empty download link for Final version
    foreach ($files as $key => $value) { //Loop for files
        $token = explode("-", $value);
        $token = array_map('trim', $token);
        if($name[1] == $token[1]) { //if second part of title after (-) is equal to second part of array data after (-)
            if(isset($token[2])) { //if have more terms after -
                $token[2] = ($token[2] == "Final Version") ? $token[2]." Download" : $token[2]; //adds download text if final version is obtained.
                if($token[2] == "Final Version") { //if it is final version
                    $download = join(" ",$token); //join all tokens and sets download variable 
                }
            }
            array_push($data, $token); //Push array to array data
        }
    }
    /*This is the section in which all the tokens are combined and sets the variables to array*/
    foreach ($data as $key => $value) {
        $temp = ""; 
        foreach ($value as $k => $v) {
            $temp .= " ".$v;
        }
        $data[$key] = $temp;
    }


    echo "This is matched data with title <b>".join("&nbsp;",$name)."</b><br>";
    var_dump($data);
    echo "<br>This is download variable <br>";
    var_dump($download);
