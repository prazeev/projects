<?php
    $path = "./wp-content/uploads/webvideos/";
    $webdir = site_url()."/wp-content/uploads/webvideos/";
    $webdirclean = site_url();
    $post_title = html_entity_decode(get_the_title());
    
    
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS));
    $files = array();
    $notAllowedExtension = array('jpg', 'vtr', 'html', 'htm' );
        
    foreach($iterator as $file){
    
    if(!in_array($file->getExtension(), $notAllowedExtension) && !$file->isDir())
    
    $files[filemtime($file->getPathname())] = $file->getPathname();
    }
    
    ksort($files);
    
    //echo "<pre>" . print_r($files, true) . "</pre>";
    
    



$name = $post_title;
$name = array_map('trim',explode("-", $name));
$data = array();
$download = "";
    foreach ($files as $key => $value) {
        $token = explode("-", $value);
        $token = array_map('trim', $token);
        if($name[1] == $token[1]) {
            if(isset($token[2])) {
                $token[2] = ($token[2] == "Final Version") ? $token[2]." Download" : $token[2];
                if($token[2] == "Final Version") {
                    $download = join(" ",$token);
                }
            }
            array_push($data, $token);
        }
    }
    foreach ($data as $key => $value) 
        $temp = "";
        foreach ($value as $k => $v) {
            $temp .= " ".$v;
        }
        $data[$key] = $temp;
    }





    foreach($data as $file => $date){
    $title=$data[$file]; 
    
    $cleantitle = basename($title, ".mp4");
    
    if( $i==$autoplay ) $file_main = $title; 
    $output .= "" . PHP_EOL . 
    "<tr> 
    <td><a href=\"javascript:loadVideo('$webdirclean$title')\"> $cleantitle (Click Me)</a>
    </td>
        <td>$download</td>		
    
      </tr>"
    . PHP_EOL;
    $i++;
    }
?>