<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Model extends CI_Model {
	public function __construct() {
		parent::__construct();
		$this->load->database();
	}

	public function adminLogin($username, $password) {
		$this->db->where(array('username' => $username));
		$query = $this->db->get('admin');
		if($query->num_rows() !=0) {
		$row = $query->row();
		if(password_verify($password, $row->password)) {
			$this->session->set_userdata(array(
				'logged' => 1,
				'admin' => $username
				));
			return 1;
		}
		}
		return 0;
	}

	public function checkUser($id) {
		$this->db->select('username');
		$this->db->where(array('username' => $id));
		$query = $this->db->get('users');
		return $query->num_rows();
	}

	public function getTenders() {
		$this->db->select('sn, name, district, department, pdf');
		$this->db->order_by('sn','DESC');
		$query = $this->db->get('tenders');
		return $query->result_array();
	}

	public function getUsers() {
		$this->db->select('sn,name, address1, address2, mobile_no, email, username , is_verified');
		$query = $this->db->get('users');
		return $query->result_array();
	}

	public function addTender() {
		$name = $this->input->post('name');
		$district = $this->input->post('district');
		$department = $this->input->post('department');
		define ("filesplace","./assets/pdf");
		if (is_uploaded_file($_FILES['pdffile']['tmp_name'])) {
			 if ($_FILES['pdffile']['type'] != "application/pdf") {
 				return FALSE;
				$this->session->set_flashdata('error', 'File is not pdf.');
 			  } else {
 			  	$name_of_file = time();
 				$result = move_uploaded_file($_FILES['pdffile']['tmp_name'], filesplace."/$name_of_file.pdf");
 				if ($result) {
					$data = array(
					'name' => $name,
					'district' => $district,
					'department' => $department,
					'pdf' => 'assets/pdf/'.$name_of_file.'.pdf',
					'time' => time()
				);
				$this->db->insert('tenders', $data);
 					return TRUE;
 				}
 				else {
					$this->session->set_flashdata('error', 'Problem occured.');
 					return FALSE;
 				}
			}
 		} 
	}

	public function editTender($id) {
		$name = $this->input->post('name');
		$district = $this->input->post('district');
		$department = $this->input->post('department');
		$data = array(
				'name' => $name,
				'district' => $district,
				'department' => $department
			);
		$this->db->set($data);
		$this->db->where(array("sn" => $id));
		$this->db->update('tenders');
	}


	public function editUser($id) {
		$name = $this->input->post('name');
		$address1 = $this->input->post('address1');
		$address2 = $this->input->post('address2');
		$mobile_no = $this->input->post('mobile_no');
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$bank_name = $this->input->post('bank_name');
		$bank_number = $this->input->post('bank_number');
		$holder_name = $this->input->post('holder_name');
		$data = array(
				'name' => $name,
				'address1' => $address1,
				'address2' => $address2,
				'mobile_no' => $mobile_no,
				'email' => $email,
				'password' => password_hash($password, PASSWORD_DEFAULT),
				'bank_name' => $bank_name,
				'bank_number' => $bank_number,
				'holder_name' => $holder_name,
				'is_verified' => 1
			);
		$this->db->set($data);
		$this->db->where(array("sn" => $id));
		$this->db->update('users');
	}

	public function tender_details($id) {
		$this->db->select('sn, name, district, department, pdf');
		$this->db->where(array('sn' => $id));
		$query = $this->db->get('tenders');
		return $query->result_array();
	}

	public function user_details($id) {
		$this->db->select('sn,name, address1, address2, mobile_no, email, username,password, bank_number, holder_name, bank_name, is_verified');
		$this->db->where(array('sn' => $id));
		$query = $this->db->get('users');
		return $query->result_array();
	}

	function removeuser($id) {
		$query = $this->db->get_where('users', array('sn' => $id));
		if($query->num_rows() == 1) {
			$this->db->delete('users', array('sn' => $id));
			return 1;
		}
		return 0;
	}

	function removeTender($id) {
		$query = $this->db->get_where('tenders', array('sn' => $id));
		if($query->num_rows() == 1) {
			$this->db->delete('tenders', array('sn' => $id));
			return 1;
		}
		return 0;
	}


}

/* End of file Admin_Model.php */
/* Location: ./application/models/Admin_Model.php */