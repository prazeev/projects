<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function login($username, $password) {
		$this->db->where(array('username' => $username, 'is_verified' => 1));
		$query = $this->db->get('users');
		if($query->num_rows() !=0) {
		$row = $query->row();
		if(password_verify($password, $row->password)) {
			$this->session->set_userdata(array(
				'logged' => 1,
				'username' => $username
				));
			return 1;
		}
		}
		return 0;
	}

	public function bid_add_remove($tender, $username) {
		$this->db->where(array('sn' => $tender));
		$query = $this->db->get('tenders');
		if($query->num_rows() == 1) {
			$query = $this->db->get_where("bid",array('username' => $username, 'tender' => $tender));
			if(!$query->num_rows()) {
				$this->db->insert("bid",array(
					'tender' => $tender,
					'username' => $username,
					'time' => time()
					));
				return 1;
			} else {
				$this->db->delete("bid",array('tender' => $tender , 'username' => $username));
				return 1;
			}
		} else {
			return 0;
		}
	}

	public function bid_check($tender, $username) {
		$query = $this->db->get_where("bid", array('tender' => $tender, 'username' => $username));
		return $query->num_rows();
	}

	public function bid_list($tender) {
		$query = $this->db->get_where("bid", array('tender' => $tender));
		return $query->result();
	}

	public function signup() {
		$name = $this->input->post('name');
		$address1 = $this->input->post('address1');
		$address2 = $this->input->post('address2');
		$mobile_no = $this->input->post('mobile_no');
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$username = $this->input->post('username');
		$data = array(
				'name' => $name,
				'address1' => $address1,
				'address2' => $address2,
				'mobile_no' => $mobile_no,
				'email' => $email,
				'username' => $username,
				'password' => password_hash($password, PASSWORD_DEFAULT)
			);
		$this->db->insert('users',$data);
	}

	public function userExists($username) {
		$query = $this->db->get_where('users', array('username' => $username));
		if($query->num_rows() == 0)
			return 0;
		else
			return 1;
	}

	public function userDetails($username) {
		$query = $this->db->get_where('users', array('username' => $username));
		return $query->result_array();
	}

	public function viewTender($id) {
		$query = $this->db->get_where('tenders', array('sn' => $id));
		return $query->result_array();
	}


	public function latestTenders($total = FALSE) {
		$this->db->order_by("sn","DESC");
		if($total)
			$this->db->limit($total);
		$query = $this->db->get('tenders');
		return $query->result_array();
	}

	public function myBids($total = FALSE) {
		$this->db->order_by("sn","DESC");
		if($total)
			$this->db->limit($total);
		$query = $this->db->get_where('bid',array('username' => $this->session->username));
		return $query->result_array();
	}

	public function latestTendersByFilter($district, $department) {
		$this->db->order_by("sn","DESC");
		$query = $this->db->get_where('tenders', array('district' => $district, 'department' => $department));
		return $query->result_array();
	}

	public function department($district) {
		$this->db->select("department");
		$this->db->order_by("sn","DESC");
		$query = $this->db->get_where('tenders',array('district' => $district));
		return $query->result_array();
	}


}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */