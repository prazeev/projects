<!DOCTYPE html>
<html>
<head>
	<title><?=$title?></title>
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/admin.css')?>">
</head>
<body>
<div class="row">
	<div class="well-black">
			<div class="logo"><?=anchor(site_url('pub/home'),'TENDER MANAGEMENT',' title="Home"'); ?></div>
	</div>
	<div class="col-md-12">
		<div class="container">
			<?=$this->session->flashdata('message') != NULL ?  '<div class="alert alert-success">'.$this->session->flashdata('message').'</div>' : '';?>
			<div class="row">
				<div class="col-md-12">
					<h3>Latest Tenders</h3>
					<div class="col-md-6">
						<div class="form-group">
							<label>Select District</label>
							<select name="district" class="form-control">
								<?php
									$latest = array();
									foreach ($latest_tenders as $key => $value) {
										array_push($latest, $value['district']);
									}
									$latest = array_unique($latest);
								?>
								<option>- Select District -</option>
								<?php foreach($latest as $tenders) :?>
								<option value="<?=$tenders; ?>"><?=$tenders; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group" id="depart">
							
						</div>
					</div>
					<table class="table table-striped table-responsive table-bordered">
						<tr>
							<th>ID</th>
							<th>Name</th>
							<th>District</th>
							<th>Department</th>
							<th>Action</th>
						</tr>
						<tbody id="results">
						<?php foreach($latest_tenders as $key => $value) : ?>
							<tr>
								<td><?=$value['sn']; ?></td>
								<td><?=$value['name']; ?></td>
								<td><?=$value['district']; ?></td>
								<td><?=$value['department']; ?></td>
								<td><?=anchor(base_url($value['pdf']), 'Download', 'title="View '.$value['name'].'"'); ?> | <?=anchor(site_url('pub/view/'.$value['sn']), 'View', 'title="View '.$value['name'].'"'); ?></td>
							</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
<script src="https://code.jquery.com/jquery-3.1.0.min.js" integrity="sha256-cCueBR6CsyA4/9szpPfrX3s49M9vUU5BgtiJj06wt/s=" crossorigin="anonymous"></script>
<script type="text/javascript">
	$(function() {
		$(document).on("change", "[name=district]", function() {
			var data = $("[name=district]").val();
			$.ajax({url: "<?=base_url('pub/depart'); ?>", data: {
				name : data
			}, type:'POST', success: function(result){
        		$("#depart").html(result);
    		}});
		});

		$(document).on("change","[name=department]", function() {
			var depart = $("[name=department]").val();
			var district = $("[name=district]").val();
			$.ajax({url: "<?=base_url('pub/latest_by_filter'); ?>", data: {
				district : district,
				depart: depart
			}, type:'POST', success: function(result){
        		$("#results").html(result);
    		}});
		});
	});
</script>
</html>