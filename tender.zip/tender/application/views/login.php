<!DOCTYPE html>
<html>
<head>
	<title>User Login Page</title>
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/admin.css')?>">
</head>
<body class="login">
	<div class="container">
		<div class="col-md-6 col-md-offset-3">
			<div class="thumbnail">
				<div class="logo">Tender System</div>
				<h4>Login</h4>
				<hr>
				<?=$this->session->flashdata('message') != NULL ?  '<div class="alert alert-success">'.$this->session->flashdata('message').'</div>' : '';?>
				<?=form_open(base_url('pub'));?>
					<?=form_error('username', '<div class="alert alert-danger">', '</div>'); ?>
					<input type="text" name="username" class="form-control" placeholder="username" value="<?=set_value('username')?>">
					<br>
					<?=form_error('pass','<div class="alert alert-danger">', '</div>'); ?>
					<input type="password" name="pass" class="form-control" placeholder="Password">
					<br>
					<input type="submit" name="submit" value="Login" class="btn-primary btn">
				</form>
				<br>
				<b>OR <a href="<?=site_url('pub/signup')?>" class="btn btn-danger">Register as new user</a>
			</div>
		</div>
	</div>
	
</body>
</html>