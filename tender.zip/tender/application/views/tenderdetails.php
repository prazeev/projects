<!DOCTYPE html>
<html>
<head>
	<title><?=$title?></title>
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/admin.css')?>">
</head>
<body>
<div class="row">
	<div class="well-black">
			<div class="logo"><?=anchor(site_url('pub/home'),'TENDER MANAGEMENT',' title="Home"'); ?></div>
	</div>
	<div class="col-md-12">
		<div class="container">
			<?=$this->session->flashdata('message') != NULL ?  '<div class="alert alert-success">'.$this->session->flashdata('message').'</div>' : '';?>
			<div class="row">
				<div class="col-md-7 col-sm-7">
				<h3>View tender -- <?=$name; ?></h3>
					<div class="panel panel-success">
						<div class="panel-heading"><?=$name; ?></div>
						<div class="panel-body">
							<ul class="list-group">
								<div class="list-group-item">District: <?=$district; ?></div>
								<div class="list-group-item">Department: <?=$department; ?></div>
								<div class="list-group-item">Created date: <?=mdate("%Y/%m/%d", $time); ?></div>
							</ul>
						</div>
						<div class="panel-footer">
							<a href="<?=site_url('pub/bid/'.$sn); ?>" class="btn btn-lg <?=($bid) ? "btn-danger" : "btn-success"; ?> btn-block"><?=($bid) ? "Unbid " : "Bid"; ?> this Tender</a>
						</div>
					</div>
				</div>
				<div class="col-md-5 col-sm-5">
				<h3>&nbsp;</h3>
					<div class="panel panel-default">
						<div class="panel-heading">Rules and Regulations</div>
						<div class="panel-body">
							<ul class="list-group">
								<li class="list-group-item"></li>
								<li class="list-group-item"></li>
								<li class="list-group-item"></li>
								<li class="list-group-item"></li>
								<li class="list-group-item"></li>
								<li class="list-group-item"></li>
								<li class="list-group-item"></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<div class="panel panel-default">
							<div class="panel-heading">
								Bids on this Tender "<?=$name; ?>"
							</div>
							<div class="panel-body">
								<?php
								foreach ($bid_list as $key => $value) {
									echo $value->username." <i style='color:grey'>(on ".mdate("%M,%d %Y", $value->time).")</i>";
								}
								if(!sizeof($bid_list))
									echo "<div class='alert alert-danger'>No data found!!</div>";
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>