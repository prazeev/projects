<!DOCTYPE html>
<html>
<head>
	<title><?=$title?></title>
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/admin.css')?>">
</head>
<body>
<div class="row">
	<div class="well-black">
			<div class="logo"><?=anchor(site_url('pub/home'),'TENDER MANAGEMENT',' title="Home"'); ?></div>
	</div>
	<div class="col-md-12">
		<div class="container">
			<?=$this->session->flashdata('message') != NULL ?  '<div class="alert alert-success">'.$this->session->flashdata('message').'</div>' : '';?>
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<div class="panel panel-success">
						<div class="panel-heading">
							My Bids
						</div>
						<div class="panel-body">
							<table class="table table-striped table-responsive table-bordered">
								<tr>
									<th>ID</th>
									<th>Bid No</th>
									<th>Time</th>
									<th>Action</th>
								</tr>
								<?php foreach($bid as $bids) :?>
								<tr>
									<td><?=$bids['sn']; ?></td>
									<td><?=$bids['tender']; ?></td>
									<td><?=mdate("%M,%d %Y",$bids['time']); ?></td>
									<td><?=anchor(site_url('pub/view/'.$bids['tender']), 'View', 'title="View '.$bids['tender'].'"'); ?></td>
								</tr>
								<?php endforeach; ?>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>