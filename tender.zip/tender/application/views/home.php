<!DOCTYPE html>
<html>
<head>
	<title><?=$title?></title>
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/admin.css')?>">
</head>
<body>
<div class="row">
	<div class="well-black">
			<div class="logo"><?=anchor(site_url('pub/home'),'TENDER MANAGEMENT',' title="Home"'); ?></div>
	</div>
	<div class="col-md-12">
		<div class="container">
			<h3>Menus</h3>
			<?=$this->session->flashdata('message') != NULL ?  '<div class="alert alert-success">'.$this->session->flashdata('message').'</div>' : '';?>
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="panel panel-success">
						<div class="panel-heading">
							Personal Data
						</div>
						<div class="panel-body">
							<ul class="list-group">
								<li class="list-group-item"><?=$name; ?></li>
								<?=(!empty($address1)) ? "<li class='list-group-item'>".$address1."</li>": ""; ?>
								<?=(!empty($address2)) ? "<li class='list-group-item'>".$address2."</li>": ""; ?>
								<?=(!empty($mobile_no)) ? "<li class='list-group-item'>".$mobile_no."</li>": ""; ?>
								<?=(!empty($email)) ? "<li class='list-group-item'>".$email."</li>": ""; ?>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6">
					<div class="panel panel-success">
						<div class="panel-heading">
							Bank Details
						</div>
						<div class="panel-body">
							Bank name: <?=$bank_name; ?><hr>
							Bank number: <?=$bank_number; ?><hr>
							Holder name: <?=$holder_name; ?>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="panel panel-success">
						<div class="panel-heading">
							My Bids
							<div class="pull-right">
                    			<a class="btn btn-default btn-xs btn-filter" href="<?=site_url('pub/bidlist'); ?>"><span class="glyphicon glyphicon-filter"></span> View All</a>
                			</div>
						</div>
						<div class="panel-body">
							<table class="table table-striped table-responsive table-bordered">
								<tr>
									<th>ID</th>
									<th>Bid No</th>
									<th>Time</th>
									<th>Action</th>
								</tr>
								<?php foreach($my_bids as $bids) :?>
								<tr>
									<td><?=$bids['sn']; ?></td>
									<td><?=$bids['tender']; ?></td>
									<td><?=mdate("%M,%d %Y",$bids['time']); ?></td>
									<td><?=anchor(site_url('pub/view/'.$bids['tender']), 'View', 'title="View '.$bids['tender'].'"'); ?></td>
								</tr>
								<?php endforeach; ?>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6">
					<div class="panel panel-success">
						<div class="panel-heading">
							Latest Tenders
							<div class="pull-right">
                    			<a class="btn btn-default btn-xs btn-filter" href="<?=site_url('pub/latest'); ?>"><span class="glyphicon glyphicon-filter"></span> View All</a>
                			</div>
						</div>
						<div class="panel-body">
							<table class="table table-striped table-responsive table-bordered">
								<tr>
									<th>ID</th>
									<th>Name</th>
									<th>District</th>
									<th>Department</th>
									<th>Action</th>
								</tr>
								<?php foreach($latest_tenders as $tenders) :?>
								<tr>
									<td><?=$tenders['sn']; ?></td>
									<td><?=$tenders['name']; ?></td>
									<td><?=$tenders['district']; ?></td>
									<td><?=$tenders['department']; ?></td>
									<td><?=anchor(base_url($tenders['pdf']), 'Download', 'title="Download '.$tenders['name'].'"'); ?> | <?=anchor(site_url('pub/view/'.$tenders['sn']), 'View', 'title="View '.$tenders['name'].'"'); ?></td>
								</tr>
								<?php endforeach; ?>
							</table>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<div class="panel panel-success">
						<div class="panel-heading">
							Notifications
							<div class="pull-right">
                    			<button class="btn btn-default btn-xs btn-filter"><span class="glyphicon glyphicon-filter"></span> View All</button>
                			</div>
						</div>
						<div class="panel-body">
							<div class="alert alert-danger">
								No data to display.
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>