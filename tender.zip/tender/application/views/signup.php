<!DOCTYPE html>
<html>
<head>
	<title>User Registration</title>
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/admin.css')?>">
</head>
<body class="login">
	<div class="container">
		<div class="col-md-6 col-md-offset-3">
				<div class="logo">TENDER MANAGEMENT</div>
			<div class="thumbnail">
				<h3>Open Account </h3>
				<hr>
				<?=form_open(site_url('pub/signup'));?>
					<label>Full name  </label>
					<?=form_error('name', '<div class="alert alert-danger">', '</div>');?>
					<input type="text" name="name" class="form-control" value="<?=set_value('name')?>">
					<br>
					<label> Address one </label>
					<?=form_error('address1', '<div class="alert alert-danger">', '</div>');?>
					<input type="text" name="address1" class="form-control" value="<?=set_value('address1')?>">
					<br>
					<label>Address 2 </label>
					<?=form_error('address2', '<div class="alert alert-danger">', '</div>');?>
					<input type="text" name="address2" class="form-control" value="<?=set_value('address2')?>">
					<br>
					<label>Mobile no</label>
					<?=form_error('mobile_no', '<div class="alert alert-danger">', '</div>');?>
					<input type="number" name="mobile_no" class="form-control" value="<?=set_value('mobile_no')?>">
					<br>
					<label>Email id </label>
					<?=form_error('email', '<div class="alert alert-danger">', '</div>');?>
					<input type="email" name="email" class="form-control" value="<?=set_value('email')?>">
					<br>
					<label>Username </label>
					<?=form_error('username', '<div class="alert alert-danger">', '</div>');?>
					<input type="text" name="username" class="form-control" value="<?=set_value('username')?>">
					<br>
					<label>Password </label>
					<?=form_error('password', '<div class="alert alert-danger">', '</div>');?>
					<input type="password" name="password" class="form-control" value="<?=set_value('password')?>">
					<br>
					
					<br>
					<input type="submit" name="submit" value="Open account " class="btn-primary btn">
				</form>
				<br>
				<b>Already a member ? <a href="<?=site_url('pub')?>" class="btn btn-danger">Login!! </a>
			</div>
		</div>
	</div>
	
</body>
</html>