	<div class="col-md-10">
	<h3>Add Tenders</h3>
		<?=validation_errors('<div class="alert alert-danger">', '</div>');?>
		<?=form_open_multipart(base_url('admin/addtender'))?>
		<label>Tender Name</label>
		<input class="form-control" name="name" type="text">
		<label>District</label>
		<input type="text" name="district" class="form-control">
		<label>Department</label>
		<input type="text" name="department" class="form-control">
		<br>
		<input name="submit" type="submit" class="btn btn-primary" value="Add Tender">
	</div>
</div>
</body>
