
	<div class="col-md-10">
	<h3>Recent Tenders</h3>
	<?=$this->session->flashdata('message') != NULL ?  '<div class="alert alert-success">'.$this->session->flashdata('message').'</div>' : '';?>
	<?=$this->session->flashdata('error') != NULL ?  '<div class="alert alert-danger">'.$this->session->flashdata('error').'</div>' : '';?>
	<?php
		$template = array(
            'table_open' => '<table border="0" cellpadding="2" cellspacing="1" class="table table-striped table-responsive table-bordered">'
		);
		$this->table->set_heading('ID', 'Name ', 'District', 'Department' ,'Action');
		$this->table->set_template($template);
		foreach ($tenders as $key => $value) {
			array_push($tenders[$key],array('action' => "<a href='".site_url('admin/edittender/'.$value['sn'])."'>Edit</a> | <a href='".site_url('admin/removetender/'.$value['sn'])."'>Delete</a>"));
		}
		//echo $this->table->generate($tenders);
		?>
		<table class="table table-striped table-responsive table-bordered">
								<tr>
									<th>ID</th>
									<th>Name</th>
									<th>District</th>
									<th>Department</th>
									<th>Action</th>
								</tr>
								<?php foreach($tenders as $tender) :?>
								<tr>
									<td><?=$tender['sn']; ?></td>
									<td><?=$tender['name']; ?></td>
									<td><?=$tender['district']; ?></td>
									<td><?=$tender['department']; ?></td>
									<td><?="<a href='".base_url($tender['pdf'])."'>Download</a> | <a href='".site_url('admin/edittender/'.$tender['sn'])."'>Edit</a> | <a href='".site_url('admin/removetender/'.$tender['sn'])."'>Delete</a>"; ?></td>
								</tr>
								<?php endforeach; ?>
							</table>
	</div>
</div>
</body>
