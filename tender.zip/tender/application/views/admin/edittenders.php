	<div class="col-md-10">
	<h3>Edit Tenders</h3>
		<?=validation_errors('<div class="alert alert-danger">', '</div>');?>
		<?php foreach($tender_details as $tender) : ?>
		<?=form_open(base_url('admin/edittender/'.$tender["sn"]))?>
		<label>Tender Name</label>
		<input class="form-control" name="name" type="text" value="<?=$tender['name']; ?>">
		<label>District</label>
		<input type="text" name="district" class="form-control" value="<?=$tender['district']; ?>">
		<label>Department</label>
		<input type="text" name="department" class="form-control" value="<?=$tender['department']; ?>">
		<label>PDF file</label>
		<input type="file" name="pdffile" class="form-control" size="20">
		<br>
		<button name="submit" type="submit" class="btn btn-primary">Edit Tender</button>
		</form>
		<?php endforeach; ?>
	</div>
</div>
</body>
