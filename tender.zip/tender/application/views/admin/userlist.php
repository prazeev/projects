
	<div class="col-md-10">
	<h3>Recent Users</h3>
	<?=$this->session->flashdata('message') != NULL ?  '<div class="alert alert-success">'.$this->session->flashdata('message').'</div>' : '';?>
	<?php
		$template = array(
            'table_open' => '<table border="0" cellpadding="2" cellspacing="1" class="table table-striped table-responsive table-bordered">'
		);
		$this->table->set_heading('ID', 'Name ', 'Address 1', 'Address 2' ,'Mobile no','Email id','Username','Status','Action');
		$this->table->set_template($template);
		foreach ($users as $key => $value) {
			array_push($users[$key], "<a href='".site_url('admin/edituser/'.$value['sn'])."'>Edit</a> | <a href='".site_url('admin/removeuser/'.$value['sn'])."'>Delete</a>");
			$users[$key]['is_verified'] = ($value['is_verified']) ? "<span style='color:green'>Verified</span> " : "<a href='".site_url('admin/edituser/'.$value['sn'])."'>Verify</a>";
		}
		echo $this->table->generate($users);
		?>
	</div>
</div>
</body>
