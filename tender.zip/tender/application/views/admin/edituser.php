	<div class="col-md-10">
	<h3>Edit Users</h3>
		<?=validation_errors('<div class="alert alert-danger">', '</div>');?>
		<?php foreach($user_details as $user) : ?>
		<?=form_open(base_url('admin/edituser/'.$user["sn"]))?>
		<label>Name</label>
		<input class="form-control" name="name" type="text" value="<?=$user['name']; ?>">
		<label>Address 1</label>
		<input type="text" name="address1" class="form-control" value="<?=$user['address1']; ?>">
		<label>Address 2</label>
		<input type="text" name="address2" class="form-control" value="<?=$user['address2']; ?>">
		<label>Mobile number</label>
		<input type="text" name="mobile_no" class="form-control" value="<?=$user['mobile_no']; ?>">
		<label>Email id</label>
		<input type="email" name="email" class="form-control" value="<?=$user['email']; ?>">
		<label>New Password</label>
		<input type="text" name="password" class="form-control" placeholder="NEW PASSWORD">
		<label>Username</label>
		<input type="text" name="username" class="form-control" value="<?=$user['username']; ?>" readonly>
		<br>
		<div class="panel panel-success">
			<div class="panel-heading">
				Verifying **
			</div>
			<div class="panel-body">
				
				<?php if(!$user['is_verified']) : ?>
				<div class="alert alert-danger">
					This user is not verified.
				</div>
				<?php endif; if(empty($user['bank_number']) || empty($user['bank_name']) || empty($user['holder_name'])) : ?>
				<div class="alert alert-info">
					Change the <b>Bank Name, Number, Account Holder Name, </b> user will be auto verified.
				</div>
				<?php endif;?>
				<label>Bank name</label>
				<input type="text" name="bank_name" class="form-control" value="<?=$user['bank_name']; ?>">
				<label>Bank account Number</label>
				<input type="number" name="bank_number" class="form-control" value="<?=$user['bank_number']; ?>">
				<label>Account holder name</label>
				<input type="text" name="holder_name" class="form-control" value="<?=$user['holder_name']; ?>">
			</div>
		</div>
		<button name="submit" type="submit" class="btn btn-primary">Edit User</button>
		</form>
		<?php endforeach; ?>
	</div>
</div>
</body>
