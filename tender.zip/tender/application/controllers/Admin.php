<?php
/**
* 
*/
class Admin extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation','', 'form');
		$this->load->model('admin_model', 'admin');
		$this->load->library(array('session','table'));
		$this->load->helper(array('html','url','form'));
	}
	/* Home page for Admin Panel. Shows Login Screen */
	function index() {
		$this->form->set_rules('username', 'Username', 'required|callback_password_check');
		$this->form->set_rules('pass', 'Password', 'required');
		if($this->form->run()) {
			redirect(base_url("admin/home"));
		}
		else {
			$data['title'] = "Login";
			$this->load->view('admin/adminlogin', $data);
		}
	}

	// password checking mechanism for user login
	function password_check($str) {
		$pass = $this->input->post('pass');
		if($this->admin->adminLogin($str, $pass) != 1) {
			$this->form->set_message('password_check', 'Username and Password does not match.');
			return FALSE;
		}
		else
			echo TRUE;
	}

	// loads list of users and manpowers
	function home($type = "") {
		$this->_session();
		if($type== "") {
			$data['username'] = $this->session->userdata('username');
			$data['tenders'] = $this->admin->getTenders();
			$data['title'] = "Recent Tenders";
			$this->load->view('admin/head', $data);
			$this->load->view('admin/home');
		}
		
	}

	// adds new manpower
	public function addtender() {
		$this->_session();
		$this->form->set_rules('name', 'Tender Name', 'required|min_length[4]');
		$this->form->set_rules('district', 'District Name', 'required|min_length[4]');
		$this->form->set_rules('department', 'Department Name', 'required|min_length[4]');
		if($this->form->run()) {
			if($this->admin->addTender())
				$this->session->set_flashdata('message', 'Tender Added Successfully');
			redirect(site_url("admin/home"));
			//print_r($_FILES['pdffile']);
		}
		else {
			$data['title'] = "Add tender";
			$this->load->view('admin/head', $data);
			$this->load->view('admin/addtender');
		}
	}

// edits tender
	function edittender($id = FLASE) {
		if($id) {
			$this->_session();
			$this->form->set_rules('name', 'Tender Name', 'required|min_length[4]');
			$this->form->set_rules('district', 'District Name', 'required|min_length[4]');
			$this->form->set_rules('department', 'Department Name', 'required|min_length[4]');
			if($this->form->run()) {
				$this->admin->editTender($id);
				$this->session->set_flashdata('message', 'Tender edited Successfully');
				redirect(base_url("admin/home"));
			}
			else {
				$data['title'] = "Edit Tender";
				$data['tender_details'] = $this->admin->tender_details($id);
				$this->load->view('admin/head', $data);
				$this->load->view('admin/edittenders');
			}
		} else {
			show_404();
		}
	}

	// removes manpower
	function removetender($id = FALSE) {
		$this->_session();
		if(!$id) {
			show_404();
		}
		else {
			if($this->admin->removeTender($id) == 0) {
				$this->session->set_flashdata('message', 'This Tender Doesn\'t Exists');
			}
			else {
				$this->session->set_flashdata('message', 'Tender Deleted Successfully');
			}
			redirect(base_url('admin/home'));
		}
	}

	// loads list of users and manpowers
	function users() {
		$this->_session();
		$data['username'] = $this->session->userdata('username');
		$data['users'] = $this->admin->getUsers();
		$data['title'] = "Users List";
		$this->load->view('admin/head', $data);
		$this->load->view('admin/userlist');
	}

	

// edits tender
	function edituser($id = FLASE) {
		if($id) {
			$this->_session();
			$this->form->set_rules('name', 'Tender Name', 'required|min_length[4]');
			$this->form->set_rules('address1', 'Address one', 'required|min_length[4]');
			$this->form->set_rules('address2', 'Address two', 'required|min_length[4]');
			$this->form->set_rules('mobile_no', 'Mobile number', 'required|numeric');
			$this->form->set_rules('email', 'Email id', 'required|valid_email');
			$this->form->set_rules('username', 'Username', 'required|min_length[6]|alpha_dash|callback_user_check');
			$this->form->set_rules('password', 'Password', 'required|min_length[6]');
			$this->form->set_rules('bank_name', 'Bank name', 'required|min_length[6]');
			$this->form->set_rules('bank_number', 'Account number', 'required|min_length[6]\numeric');
			$this->form->set_rules('holder_name', 'Holder name', 'required|min_length[6]');
			if($this->form->run()) {
				$this->admin->editUser($id);
				$this->session->set_flashdata('message', 'User edited Successfully');
				redirect(base_url("admin/users"));
			}
			else {
				$data['title'] = "Edit user";
				$data['user_details'] = $this->admin->user_details($id);
				$this->load->view('admin/head', $data);
				$this->load->view('admin/edituser');
			}
		} else {
			show_404();
		}
	}

	//checks user exixts or not
	function user_check($str) {
		if(!$this->admin->checkUser($str)) {
			$this->session->set_flashdata('message', 'ID donot exist.');
			return FALSE;
		}
		else
			return TRUE;
	}

	// removes manpower
	function removeuser($id = FALSE) {
		$this->_session();
		if(!$id) {
			show_404();
		}
		else {
			if($this->admin->removeuser($id) == 0) {
				$this->session->set_flashdata('message', 'This User Doesn\'t Exists');
			}
			else {
				$this->session->set_flashdata('message', 'User Deleted Successfully');
			}
			redirect(base_url('admin/users'));
		}
	}

	// logout
	function logout() {
		$this->session->sess_destroy();
		redirect(base_url('admin'));
	}

	// checks if admin is logged in or not
	function _session() {
		if($this->session->userdata('admin') == '') {
			redirect(base_url('admin'));
		}
	}

}