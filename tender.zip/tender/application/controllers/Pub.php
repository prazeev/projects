<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pub extends CI_Controller {
	
	public function __construct()
	{		
		parent::__construct();
		$this->load->library('form_validation','', 'form');
		$this->load->model('Main_model', 'main');
		$this->load->library(array('session','table'));
		$this->load->helper(array('url','date'));
		
	}

	// login page
	function index() {
		$this->form->set_rules('username', 'Username', 'required|callback_password_check');
		$this->form->set_rules('pass', 'Password', 'required');
		if($this->form->run()) {
			redirect(site_url("pub/home"));
		}
		else {
			$this->load->view('login');
		}
	}


	public function home() {
		if(null === $this->session->username)
			redirect(base_url('pub/index'));
		$data['title'] = $this->session->username." - Home";
		foreach ($this->main->userDetails($this->session->username) as $key => $value) {
			foreach ($value as $field => $data_user) {
				$data[$field] = $data_user;
			}
		}
		$data['latest_tenders'] = $this->main->latestTenders(5);
		$data['my_bids'] = $this->main->myBids(5);
		$this->load->view('home',$data);
	}

	public function bidlist($total = FALSE) {
		if(null === $this->session->username)
			redirect(base_url('pub/index'));
		$data['bid'] = $this->main->myBids($total);
		$data['title'] = "My bids";
		$this->load->view('bidlist',$data);
	}

	public function view($id = FALSE) {
		if(null === $this->session->username)
			redirect(base_url('pub/index'));
		if(!$id)
			show_404();
		$tender = $this->main->viewTender($id);
		if(sizeof($tender)) {
			foreach ($tender as $key => $value) {
				foreach ($value as $index => $tender_details) {
					$data[$index] = $tender_details;
				}
			}
		} else  {
			show_404();
		}
		$data['title'] = $this->session->username." - ".$data['name']." - View Tender";
		$data['bid'] = $this->main->bid_check($data['sn'], $this->session->username);
		$data['bid_list'] = $this->main->bid_list($data['sn']);
		$this->load->view("tenderdetails",$data);
	}


	public function depart() {
		$district = $this->input->post("name");
		if(!$district)
			show_404();
		echo "<label>Select Department</label>
			<select name='department' class='form-control'>
			<option>- Select Department -</option>
			";
		$latest = array();
		$latest_tenders = $this->main->department($district);
		foreach ($latest_tenders as $key => $value) {
			array_push($latest, $value['department']);
		}
		$latest = array_unique($latest);
		foreach ($latest as $value) : ?>
				<option value="<?=$value; ?>"><?=$value; ?></option>
		<?php endforeach;
		echo "</select>";

		//var_dump($latest);
	}

	public function latest($per_page = FALSE) {
		if(null === $this->session->username)
			redirect(base_url('pub/index'));
		$data['latest_tenders'] = $this->main->latestTenders(($per_page) ? $per_page : FALSE);
		$data['title'] = $this->session->username." - View All Recent Tender";
		$this->load->view("latest",$data);
	}

	public function latest_by_filter() {
		$district = (null !== $this->input->post('district')) ? $this->input->post('district') : FALSE;
		$depart = (null !== $this->input->post('depart')) ? $this->input->post('depart') : FALSE;
		if(!$district || !$depart)
			$data['latest_tenders'] = $this->main->latestTenders();
		else
			$data['latest_tenders'] = $this->main->latestTendersByFilter($district, $depart);
		foreach($data['latest_tenders'] as $key => $value) : ?>
			<tr>
				<td><?=$value['sn']; ?></td>
				<td><?=$value['name']; ?></td>
				<td><?=$value['district']; ?></td>
				<td><?=$value['department']; ?></td>
				<td><?=anchor(site_url('pub/view/'.$value['sn']), 'View', 'title="View '.$value['name'].'"'); ?></td>
			</tr>
				<?php endforeach;
	}
// signup
	public function signup() {
		$this->form->set_rules('name', 'Full Name', 'required|min_length[4]');
		$this->form->set_rules('address1', 'Address one', 'required|min_length[4]');
		$this->form->set_rules('address2', 'Address two', 'required|min_length[4]');
		$this->form->set_rules('mobile_no', 'Mobile number', 'required|numeric');
		$this->form->set_rules('email', 'Email id', 'required|valid_email');
		$this->form->set_rules('username', 'Username', 'required|min_length[6]|alpha_dash|callback_user_exists');
		$this->form->set_rules('password', 'Password', 'required|min_length[6]');
		if($this->form->run()) {
			$this->main->signup();
			$this->session->set_flashdata('message', 'User created Successfully');
			redirect(site_url('pub/index'));
		}
		else
			$this->load->view('signup');
	}

		// check if username already exists
	public function user_exists($username) {
		if(!$this->main->userExists($username))
			return TRUE;
		else {
			$this->form->set_message('user_exists', 'Username already exists.');
			return FALSE;
		}
	}

	public function bid($id = FALSE)
	{
		if(!$id)
			show_404();
		$this->bid_add_remove($id);
		redirect(site_url('pub/view/'.$id));
	}
	
	function bid_add_remove($str) {
		$username = $this->session->username;
		if($this->main->bid_add_remove($str, $username) != 1) {
			return TRUE;
			$this->session->set_flashdata('message', 'Some error occured on program.');
		}
		else {
			$this->session->set_flashdata('message', 'Bid action completed successfully.');
			return TRUE;
		}
	}

	// password matching function
	function password_check($str) {
		$pass = $this->input->post('pass');
		if($this->main->login($str, $pass) != 1) {
			$this->form->set_message('password_check', 'Username and Password does not match or the id is not verified.');
			return FALSE;
		}
		else
			return TRUE;

	}

		// logout
	function logout() {
		$this->session->sess_destroy();
		redirect(base_url('pub'));
	}

}
