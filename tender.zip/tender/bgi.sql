-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2016 at 08:26 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 7.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bgi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `sn` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sn`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$V8YQbUBYVJHwsvVsziNs7.lHQK6KR5eRWrCbRE6Mi5jMFKH8ZFAES');

-- --------------------------------------------------------

--
-- Table structure for table `bid`
--

CREATE TABLE `bid` (
  `sn` int(11) NOT NULL,
  `tender` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `time` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bid`
--

INSERT INTO `bid` (`sn`, `tender`, `username`, `time`) VALUES
(10, 6, 'prazeev', 1468265254),
(11, 9, 'prazeev', 1468266219);

-- --------------------------------------------------------

--
-- Table structure for table `tenders`
--

CREATE TABLE `tenders` (
  `sn` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `district` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `pdf` varchar(200) NOT NULL,
  `time` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenders`
--

INSERT INTO `tenders` (`sn`, `name`, `district`, `department`, `pdf`, `time`) VALUES
(13, 'Bashudev Paudel', 'fcgvhbjnkm', 'fgvbhjnimk', 'assets/pdf/1468346781.pdf', 1468346781);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `sn` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `address2` varchar(200) NOT NULL,
  `mobile_no` bigint(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `is_verified` int(11) NOT NULL DEFAULT '0',
  `bank_name` varchar(200) NOT NULL,
  `bank_number` bigint(20) NOT NULL,
  `holder_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`sn`, `name`, `address1`, `address2`, `mobile_no`, `email`, `username`, `password`, `is_verified`, `bank_name`, `bank_number`, `holder_name`) VALUES
(3, 'Bashudev Paudel', 'JapaGHFGHJK', 'dfghjk', 77777, 'prazeev@gmail.com', 'prazeev', '$2y$10$Pds.395kdbRLLwPT9b/uYOeN84t.4rtxP4q3FxZL.8zn0cYWkX/p.', 1, 'Prabhu Bank', 987656789098765, 'Bashudev poudel'),
(5, 'Bashudev Paudel', 'Japan Tokio', 'drtyfguhjklm', 4567890, 'prazeev@gmail.com', 'adminn', '$2y$10$TkmSlNK1wPaUweXqybQAceBVdAHTK79LD71Dbxju/seYuewMB7DfK', 0, '', 0, ''),
(6, 'Ramu Kaka', 'Japan', 'Tokiohjsd', 98765678, 'prazeev@gmail.com', 'prazeevv', '$2y$10$YtfLKAJR1n0HXXqtaGH5reoM.m7ZmNbD5Ag0JF8Tts5fi.A4pGfFe', 0, '', 0, ''),
(7, 'Bashudev Paudel', 'Jhapa,  nepal', 'my number is 9803957606', 9860428885, 'prazeev@gmail.com', 'bashudev', '$2y$10$F.zdYgb5Cp/LqaMKfYAgEuy.hbBm9PUPVvtG9nB1Nlac6jPcx6uuq', 0, '', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `bid`
--
ALTER TABLE `bid`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `tenders`
--
ALTER TABLE `tenders`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`sn`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bid`
--
ALTER TABLE `bid`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tenders`
--
ALTER TABLE `tenders`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
