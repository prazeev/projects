<!DOCTYPE html>
<html>
<head>
	<title>Bashudev Poudel :: Freelancer from Nepal :: Protfolio Page</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500italic,300italic,300,400italic,500,700,700italic' rel='stylesheet' type='text/css'>
</head>
<body style="background:url(assets/images/startup_bg.png) no-repeat; background-attachment:fixed">
  <header>
  	<table border="0" width="100%">
  	  <tr>
  	  	<td>
  	  	  <h1>
  	  	    Bashudev Poudel
  	  	  </h1>
  	  	</td>
  	  </tr>
  	</table>
  </header>
  <div class="container">
  	<div class="img-res-pro"><img src="assets/images/myface.png"></div>
  	jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>jhdfhlhgcbfghjklhbxbfgklkgfxbhlukgcbg<br>
  </div>
<script type="text/javascript" src="assets/jq/jquery.js"></script>
</body>
</html>