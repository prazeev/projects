$(function() {
  var value = 0;
  var pos = 0;
  var progressEl = $('progress');
  var d = new Date();
  var check = 0;
  var op = 0;
function type_writer(text,target) {
    var t = [];
    var c = 0;
    var color = '';
    text = text.split('');
    for (var i = 0; i < text.length; i++) {
      if(text[i] == '<' && text[i+1] == 'b') {
        t.push('<br>');
        i += 3;
        //check-=3;
      }
      else if(text[i] == '&' && text[i+1] == 'n') {
        t.push('&nbsp;');
        i += 5;
       // check += 5;
      }
      else if(text[i] == '{' && text[i+1] != '/') {
        if(text[i+1] == '#') {
          while(text[++i] != '}') {
            color = color+text[i];
          }
          c = 1;
        }
        if(text[i+1] == 't') {

        }
      }
      else if(text[i] == '{' && text[i+1] == '/') {
        if(text[i+2] == '#') {
          c = 0;
          color = '';
          while(text[++i] != '}') {}
        }
      }
      else {
        if(c == 1) {
          t.push("<span style='color:"+color+"'>"+text[i]+"</span>");
          //check += "<span style='color:".length + color.length + "'>".length + "</span>".length;
        }
        else {
          t.push(text[i]);
        }
      }
    };
    text = t;
    var i = 0; var j = 0;
    var after_process = setInterval(function() {
      if(j == i) {
        if(text[i] == '.') {
          $(target).append(text[i]);
          j -= 20;
          //check++;
        }
        else if(text[i] == ':') {
          $(target).append(text[i]);
          //check++;
          j -= 10;
        } else {
          $(target).append(text[i]);
          //check++;
        }
          $("body").scrollTop($("body")[0].scrollHeight);
          j++; i++;
          //check++;
      } else {
        j++;
      }
      if (j == text.length) {
          check++;
          op = 0;
          window.clearInterval(after_process);
        }
    }, 6);
}
function type_writer_clear(target) {
  $(target).html('');
}
function after_process() {
  $("center").fadeOut("fast", function() {
    $("#startup").remove();
  });
  $("#after_process").show();
  //Type writer
  type_writer('Ubuntu Loading... <br>Loading Complete!!','#after_process');
  setInterval(function() {
    //alert($("#after_process_first").html().length);
    //alert(op);
    if('Ubuntu Loading... <br>Loading Complete!!'.length == $("#after_process").html().length) { //first replace
      type_writer_clear("#after_process");
      op = 1;
      type_writer($("#after_process_first").html(),"#after_process");
    }
    else if(check == 2 && op == 0) { //second replace 
      op = 1;
      type_writer_clear("#after_process");
      type_writer($("#after_process_second").html(),"#after_process");
    }
    if(check == 3 && op == 0) { //second replace 
      op = 1;
      type_writer_clear("#after_process");
      type_writer($("#after_process_third").html(),"#after_process");
    }
    if(check == 4 && op == 0) {
      op = 1;
      $("#after_process").append("<br><br><b>Commands</b><br>\
        home<br>\
        services<br>\
        protfolio<br>\
        hireme<br>\
        about<br>\
        contact<br>\
        old<br>\
        help\
        ");
      $("#after_process").attr('blink','');
      $("#comand").css('opacity','1');
    }

    //check++;
  },1000);
}
function progress() {
  value++;
  if (value <= 100) {
    progressEl.val(value);
    pos = 1 - (value/100);
  }  else {
    after_process();
  }
  progressEl.css('background-position', '0 '+ pos +'em');
}
  $('.startup_welcome').textillate({ in: { effect: 'rollIn', delayScale: 2.5 }, callback: function() {
      $("body").css({'background':'url(assets/images/startup_bg.png) no-repeat','background-attachment':'fixed'});
      var x = 0;
      var timer = setInterval(function() {
        progress();
        if (++x === 101) {
          window.clearInterval(timer);
        }
      }, 25); 
      $("progress").css("display","inline");
    } 
  });



  //Terminal



    var id = 1;
    $('#comand').terminal(function(command, term) {
        if (command == 'help') {
            term.echo("Commands\n\
        home\n\
        services\n\
        protfolio\n\
        hireme\n\
        about\n\
        contact\n\
        old\n\
        help");
        $("body").scrollTop($("body")[0].scrollHeight);
        } else if (command == "home") {
            window.open("http://poudelbashu.com.np","_blank");
            term.echo("Home opened!!!!");
        } else if (command == "services") {
            window.open("http://poudelbashu.com.np","_blank");
            term.echo("Services opened!!!!");
        } else if (command == "protfolio") {
            window.open("profile.php","_blank");
            term.echo("Protfolio opened!!!!");
        } else if (command == "hireme") {
            window.open("http://poudelbashu.com.np","_blank");
            term.echo("Hireme opened!!!!");
        } else if (command == "about") {
            window.open("http://poudelbashu.com.np","_blank");
            term.echo("About me opened!!!!");
        } else if (command == "contact") {
            window.open("http://poudelbashu.com.np","_blank");
            term.echo("Contact opened!!!!");
        } else if (command == "old") {
            window.open("http://poudelbashu.com.np/greencreative","_blank");
            term.echo("Old website opened!!!!");
        } else {
            term.echo("unknow command " + command);
            $("body").scrollTop($("body")[0].scrollHeight);
        }
        $("body").scrollTop($("body")[0].scrollHeight);
    }, {
        greetings: "",
        prompt: 'root@poudelbashu:~# ',
        onBlur: function() {
            return false;
        }
    });
});