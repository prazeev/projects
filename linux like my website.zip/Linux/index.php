<!DOCTYPE html>
<html>
<head>
	<title>Bashudev poudel</title>
	<link rel="stylesheet" type="text/css" href="assets/css/animate.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link href="assets/css/jquery.terminal.css" rel="stylesheet"/>
	<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500italic,300italic,300,400italic,500,700,700italic' rel='stylesheet' type='text/css'>
</head>
<body>
	<div id="startup"><h1 class="startup_welcome">Welcome to poudelbashu.com.np</h1><br><br><br><br><br><br><br><br><br><br>
	<center>
		<progress max="100" style="display:none"></progress>
	</center>
	</div>
	<div id="after_process" style="display:none" blink="|"></div>
	<div id="after_process_first" style="display:none">
		Setting clock (utc): <?php date_default_timezone_set('Asia/Katmandu'); echo Date('D M d h:i:s e Y'); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Starting udev:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Loading default keymap (us):&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Setting hostname server.lap.work:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		No device found<br>
		Setting up Logical Volume Management:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Checking file system<br>
		/: clean, 91563/1537088 files, 1297902/1536215 blocks<br>
		/boot: recovering journal<br>
		/boot: clean, 35/26104 files, 14677/104388 blocks<br>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Remounting root filesystem in read-write mode:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Mounting local filesystems:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Enabling local filesystem quotas:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Starting Clean /temp directory:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Deleting conflicting ports..<br>
		Succeed!!<br>
		Setting default port `{#db4adb}80{/#db4adb}`&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Checking conflicting host..<br>
		Not found<br>
		Setting default host `{#db4adb}localhost{/#db4adb}`...&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Configuring database `localhost` with port `80`:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Clearing old sessions:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Clearing old cookies:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Checking fonts, images, javascript and css...<br>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ {#00a900}OK{/#00a900} ]<br>
		Starting..<br>
		Please Wait...
	</div>
	<div id="after_process_second" style="display:none">
		Welcome to poudelbashu.com.np<br>
		Login &nbsp;&nbsp;&nbsp;: root<br>
		Password : **************
	</div>
	<div id="after_process_third" style="display:none">
		<?php 
			if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    			$ip = $_SERVER['HTTP_CLIENT_IP'];
			} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
			} else {
    			$ip = $_SERVER['REMOTE_ADDR'];
			}
		?>
		{#008c23}<?=Date('H:i'); ?> -!- friend_ [friend_@<?=$ip; ?>] you are welcomed in poudelbashu.com.np {/#008c23} <br><br>
		{#008c23}<?=Date('H:i'); ?> :{/#008c23} Hello friends, me, Bashudev Paudel, welcome's you warmly to my site. I am a 20 years old guy from Jhapa, Nepal
		and works on web based application development. I am in this carrier since i was of 17 and currently performs development on PHP and JQ. You can hire me
		in both project basis or part time. Hope, i could satisfy you :)
	</div>
	<div id="comand" style="opacity:0"></div>
<script type="text/javascript" src="assets/jq/jquery.js"></script>
<script src="assets/jq/jquery.textillate.js"></script>
<script src="assets/jq/jquery.lettering.js"></script>
<script src="assets/jq/jquery.mousewheel-min.js"></script>
<script src="assets/jq/jquery.terminal-min.js"></script>
<script src="assets/jq/my.js"></script>
</body>
</html>