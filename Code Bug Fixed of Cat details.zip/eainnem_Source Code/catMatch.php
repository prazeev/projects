<!--/**********************************************************
* Author: Eainne McDonald
* Assignment: WE4.0 PHP Web App Assignment, Digital Skills Academy
* Student ID: xxxxx
* Date : 2016/05/21
* Ref: website link to code referenced or the book, authors name and page number
***********************************************************/-->
<?php
// this is from: Ref: https://www.developphp.com/video/PHP/Build-the-HTML-Search-Form-with-Filter-Select-List
//if (isset ($_POST['catQualities']) && $_POST['catQualities'] !=""){}*/


$ageChoice = $_GET ["ageChoice"];
$colourChoice = $_GET ["colourChoice"];
$traitChoice = $_GET ["traitChoice"];

echo "So you would like a ".$ageChoice. " year old ". $colourChoice. ", ". $traitChoice. " cat" ;

?>