<?php
/***********************************************************
* Author: Eainne McDonald
* Assignment: WE4.0 PHP Web App Assignment, Digital Skills Academy
* Student ID: xxxxx
* Date : 2016/05/21
* Ref: website link to code referenced or the book, authors name and page number
***********************************************************/

/*INCLUDE INFORMATION FROM DATABASE:
Which in this case is stored in the profileData.php file
*/
include ("profileData.php"); 


/*********************************************
*NAME FILTER FUNCTION:
*REF: Understanding the Array Map Function in PHP -https://www.youtube.com/watch?v=oTo40r3Tvz8
*REF: PHP Closures - https://www.youtube.com/watch?v=Own7BDhDFnY
*REF: Understanding Closures in PHP (part 1) - https://www.youtube.com/watch?v=T5zzYjcBzKs
**********************************************/
function get_profile_by_name ($profile, $name){
    return array_filter ($profile, function($data) use ($name){
    return $nameInput['Name'] = $name;
    });    
}

/*********************************************
*AGE FILTER FUNCTION:
*REF: Understanding the Array Map Function in PHP -  https://www.youtube.com/watch?v=oTo40r3Tvz8
*REF: PHP Closures - https://www.youtube.com/watch?v=Own7BDhDFnY
*REF: Understanding Closures in PHP (part 1) - https://www.youtube.com/watch?v=T5zzYjcBzKs
**********************************************/
function get_profile_by_age ($profile, $age){
    return array_filter ($profile, function($ageInput) use ($age){
    return $ageInput['Age'] = $age;
    });    
}


/*********************************************
*COLOUR FILTER FUNCTION:
*REF: Understanding the Array Map Function in PHP - https://www.youtube.com/watch?v=oTo40r3Tvz8
*REF: PHP Closures - https://www.youtube.com/watch?v=Own7BDhDFnY
*REF: Understanding Closures in PHP (part 1) - https://www.youtube.com/watch?v=T5zzYjcBzKs
**********************************************/
function get_profile_by_colour ($profile, $colour){
    return array_filter ($profile, function($colourInput) use ($colour){
    return $colourInput['Colour'] = $colour;
    });    
}


/*********************************************
*GENDER FILTER FUNCTION:
*REF: Understanding the Array Map Function in PHP - https://www.youtube.com/watch?v=oTo40r3Tvz8
*REF: PHP Closures - https://www.youtube.com/watch?v=Own7BDhDFnY
*REF: Understanding Closures in PHP (part 1) - https://www.youtube.com/watch?v=T5zzYjcBzKs
**********************************************/
function get_profile_by_gender ($profile, $gender){
    return array_filter ($profile, function($genderInput) use ($gender){
    return $genderInput['Gender'] = $gender;
    });    
}

/*********************************************
*PERSONALITY FILTER FUNCTION:
*REF: Understanding the Array Map Function in PHP -https://www.youtube.com/watch?v=oTo40r3Tvz8
*REF: PHP Closures - https://www.youtube.com/watch?v=Own7BDhDFnY
*REF: Understanding Closures in PHP (part 1) - https://www.youtube.com/watch?v=T5zzYjcBzKs
**********************************************/
function get_profile_by_personailty ($profile, $personality){
    return array_filter ($profile, function($personalityInput) use ($personality){
    return $personalityInput['Personality'] = $personality;
    });    
}

/*********************************************
*RESPONSE TO INPUT:
*REF: https://www.youtube.com/watch?v=8qznh1Nkj20
*REF: https://www.youtube.com/watch?v=aEpg1GE0edI
*REF: http://php.net/array_filter

**********************************************/

 if (isset($_POST['ageChoice']) && isset($_POST['colourChoice'])) {
   $ageInput = $_POST['ageChoice'];
   $colourInput = $_POST['colourChoice'];
/*
 for ($i=0; $i >=0 ; $i++) { 
        if ($profileArray[$i]['Age'] == $_POST['ageChoice'] && $profileArray[$i]['Colour'] == $_POST['colourChoice']) {
            echo "name -".$profileArray[$i]['Name'];
            break;
        }
    }*/
    foreach ($profileArray as $key => $value) {
        if($value['Age'] == $ageInput && $value['Colour'] == $colourInput) {
            echo "Name: ".$value['Name'];
            echo "<br>Age: ".$value['Age'];
            echo "<br>Colour: ".$value['Colour'];
            echo "<br>Gender: ".$value['Gender'];
            echo "<br>Personality: ".$value['Personality'];
            break;
        }
    }
 }

   

?>
