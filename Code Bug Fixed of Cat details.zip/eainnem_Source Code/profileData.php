<!--/**********************************************************
* Author: Eainne McDonald
* Assignment: WE4.0 PHP Web App Assignment, Digital Skills Academy
* Student ID: xxxxx
* Date : 2016/05/21
* REF: https://www.youtube.com/watch?v=wN1WELEix6A
***********************************************************/-->

<?php
//Acting as hardcoded database for cat profiles
$profileArray = array( 
array(  'Name' => "Toby",
        'Age' => 3, 
        'Colour' => "Ginger",
        'Gender' => "Male", 
        'Personality' => "Gentle",
        ),
                        
array(  'Name' => "Cassie",
        'Age' => 3, 
        'Colour' => "Tabby",
        'Gender' => "Female",
        'Personality' => "Playful",
        ),
                        
array(  'Name' => "Lucy",
        'Age' => 1, 
        'Colour' => "Black",
        'Gender' => "Female",
        'Personality' => "Aggressive",
        ),
array(  'Name' => "Rufus",
        'Age' => 2, 
        'Colour' => "White",
        'Gender' => "Male", 
        'Personality' => "Playful",
        ),
    
array(  'Name' => "Jack",
        'Age' => 5, 
        'Colour' => "Ginger",
        'Gender' => "Male", 
        'Personality' => "Lazy",
        ),
    
array(  'Name' => "Petal",
        'Age' => 1, 
        'Colour' => "White",
        'Gender' => "Female",
        'Personality' => "Gentle", 
        ),
array(  'Name' => "Binkie",
        'Age' => 4, 
        'Colour' => "Tabby",
        'Gender' => "Female",
        'Personality' => "Playful",
        )
);

 if (isset($_POST['ageChoice']) && isset($_POST['colourChoice'])) {
   $ageInput = $_POST['ageChoice'];
   $colourInput = $_POST['colourChoice'];
/*
 for ($i=0; $i >=0 ; $i++) { 
        if ($profileArray[$i]['Age'] == $_POST['ageChoice'] && $profileArray[$i]['Colour'] == $_POST['colourChoice']) {
            echo "name -".$profileArray[$i]['Name'];
            break;
        }
    }
    */
  }

?>